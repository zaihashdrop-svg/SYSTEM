import { useState, useEffect } from "react";
import { queryClient, getAuthToken, clearAuthToken } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import AuthPage from "@/pages/Auth";
import Dashboard from "@/pages/Dashboard";
import AdminDashboard from "@/pages/AdminDashboard";
import { SettingsProvider } from "@/lib/settings-context";

export { useSettings } from "@/lib/settings-context";

type UserRole = 'user' | 'admin' | null;

interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
}

function AppContent() {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [settingsRefreshKey, setSettingsRefreshKey] = useState(0);

  useEffect(() => {
    const checkAuth = async () => {
      const token = getAuthToken();
      if (!token) {
        setIsLoading(false);
        return;
      }

      try {
        const response = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
          setUserRole(data.user.role === 'admin' ? 'admin' : 'user');
        } else {
          clearAuthToken();
        }
      } catch (error) {
        clearAuthToken();
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const handleLoginSuccess = (isAdmin: boolean) => {
    setSettingsRefreshKey(prev => prev + 1);
    setUserRole(isAdmin ? 'admin' : 'user');
  };

  const handleLogout = () => {
    clearAuthToken();
    setUserRole(null);
    setUser(null);
    setSettingsRefreshKey(prev => prev + 1);
    queryClient.clear();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <SettingsProvider refreshKey={settingsRefreshKey}>
      {userRole === 'admin' ? (
        <AdminDashboard onLogout={handleLogout} />
      ) : userRole === 'user' ? (
        <Dashboard onLogout={handleLogout} />
      ) : (
        <AuthPage onLoginSuccess={(isAdmin) => handleLoginSuccess(isAdmin)} />
      )}
    </SettingsProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
