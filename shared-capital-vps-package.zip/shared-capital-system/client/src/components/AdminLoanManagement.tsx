import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { formatPeso } from "@/lib/format";
import { CreditCard, Pencil } from "lucide-react";

interface LoanData {
  id: string;
  userName: string;
  principal: number;
  remainingMonths: number;
  totalMonths: number;
  status: 'active' | 'paid' | 'pending';
}

interface AdminLoanManagementProps {
  loans: LoanData[];
  onEditLoan: (id: string, data: Partial<LoanData>) => void;
}

export default function AdminLoanManagement({ loans, onEditLoan }: AdminLoanManagementProps) {
  const [editingLoan, setEditingLoan] = useState<LoanData | null>(null);
  const [editPrincipal, setEditPrincipal] = useState(0);
  const [editRemainingMonths, setEditRemainingMonths] = useState(0);
  const [editStatus, setEditStatus] = useState<'active' | 'paid' | 'pending'>('active');

  const openEditModal = (loan: LoanData) => {
    setEditingLoan(loan);
    setEditPrincipal(loan.principal);
    setEditRemainingMonths(loan.remainingMonths);
    setEditStatus(loan.status);
  };

  const handleSave = () => {
    if (editingLoan) {
      onEditLoan(editingLoan.id, {
        principal: editPrincipal,
        remainingMonths: editRemainingMonths,
        status: editStatus,
      });
      setEditingLoan(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge>Active</Badge>;
      case 'paid':
        return <Badge variant="secondary">Paid</Badge>;
      case 'pending':
        return <Badge variant="outline">Pending</Badge>;
      default:
        return null;
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            All Loans
          </CardTitle>
          <Badge variant="secondary">{loans.length} loans</Badge>
        </CardHeader>
        <CardContent>
          {loans.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No loans in the system.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Principal</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loans.map((loan) => (
                  <TableRow key={loan.id} data-testid={`loan-row-${loan.id}`}>
                    <TableCell className="font-medium">{loan.userName}</TableCell>
                    <TableCell className="font-mono">{formatPeso(loan.principal)}</TableCell>
                    <TableCell>
                      {loan.totalMonths - loan.remainingMonths} / {loan.totalMonths} months
                    </TableCell>
                    <TableCell>{getStatusBadge(loan.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button 
                        size="icon" 
                        variant="ghost"
                        onClick={() => openEditModal(loan)}
                        data-testid={`button-edit-loan-${loan.id}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!editingLoan} onOpenChange={() => setEditingLoan(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Loan</DialogTitle>
            <DialogDescription>Update loan details for {editingLoan?.userName}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-principal">Principal</Label>
              <Input
                id="edit-principal"
                type="number"
                value={editPrincipal}
                onChange={(e) => setEditPrincipal(parseFloat(e.target.value) || 0)}
                data-testid="input-edit-principal"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-remaining">Remaining Months</Label>
              <Input
                id="edit-remaining"
                type="number"
                min={0}
                max={5}
                value={editRemainingMonths}
                onChange={(e) => setEditRemainingMonths(parseInt(e.target.value) || 0)}
                data-testid="input-edit-remaining"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status">Status</Label>
              <Select value={editStatus} onValueChange={(v) => setEditStatus(v as typeof editStatus)}>
                <SelectTrigger data-testid="select-edit-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingLoan(null)}>Cancel</Button>
            <Button onClick={handleSave} data-testid="button-save-loan">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
