import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPeso, formatDate } from "@/lib/format";
import { Check, X, CreditCard } from "lucide-react";

interface PendingLoan {
  id: string;
  userName: string;
  userEmail: string;
  principal: number;
  monthlyPayment: number;
  requestedAt: Date | string;
}

interface AdminPendingLoansProps {
  pendingLoans: PendingLoan[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export default function AdminPendingLoans({ pendingLoans, onApprove, onReject }: AdminPendingLoansProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Pending Loan Applications
        </CardTitle>
        <Badge variant="secondary">{pendingLoans.length} pending</Badge>
      </CardHeader>
      <CardContent>
        {pendingLoans.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No pending loan applications.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Principal</TableHead>
                <TableHead>Monthly Payment</TableHead>
                <TableHead>Requested</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingLoans.map((loan) => (
                <TableRow key={loan.id} data-testid={`pending-loan-${loan.id}`}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{loan.userName}</p>
                      <p className="text-sm text-muted-foreground">{loan.userEmail}</p>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono font-medium">{formatPeso(loan.principal)}</TableCell>
                  <TableCell className="font-mono">{formatPeso(loan.monthlyPayment)}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(loan.requestedAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => onApprove(loan.id)}
                        data-testid={`button-approve-loan-${loan.id}`}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => onReject(loan.id)}
                        data-testid={`button-reject-loan-${loan.id}`}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
