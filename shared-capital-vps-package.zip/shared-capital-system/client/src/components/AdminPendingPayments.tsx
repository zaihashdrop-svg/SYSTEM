import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPeso, formatDate } from "@/lib/format";
import { Check, Loader2, Banknote } from "lucide-react";

interface PendingPayment {
  id: string;
  userName: string;
  userEmail: string;
  amount: number;
  loanPrincipal: number;
  loanBalance: number;
  submittedAt: Date;
}

interface AdminPendingPaymentsProps {
  pendingPayments: PendingPayment[];
  onVerify: (id: string) => void;
  isVerifying?: boolean;
}

export default function AdminPendingPayments({ 
  pendingPayments, 
  onVerify,
  isVerifying 
}: AdminPendingPaymentsProps) {
  if (pendingPayments.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Banknote className="h-5 w-5" />
            Pending Payments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8" data-testid="no-pending-payments">
            No payments waiting for verification.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Banknote className="h-5 w-5" />
          Pending Payments
          <Badge variant="destructive">{pendingPayments.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Payment Amount</TableHead>
              <TableHead>Loan Balance</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {pendingPayments.map((payment) => (
              <TableRow key={payment.id} data-testid={`row-payment-${payment.id}`}>
                <TableCell>
                  <div>
                    <p className="font-medium">{payment.userName}</p>
                    <p className="text-sm text-muted-foreground">{payment.userEmail}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="font-mono font-semibold text-chart-2" data-testid={`payment-amount-${payment.id}`}>
                    {formatPeso(payment.amount)}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    <p className="font-mono">{formatPeso(payment.loanBalance)}</p>
                    <p className="text-muted-foreground">of {formatPeso(payment.loanPrincipal)} principal</p>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm">{formatDate(payment.submittedAt)}</span>
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    size="sm"
                    onClick={() => onVerify(payment.id)}
                    disabled={isVerifying}
                    data-testid={`button-verify-payment-${payment.id}`}
                  >
                    {isVerifying ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Check className="h-4 w-4 mr-1" />
                        Received
                      </>
                    )}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
