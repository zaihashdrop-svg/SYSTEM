import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPeso, formatDate } from "@/lib/format";
import { Check, X, Coins } from "lucide-react";

interface PendingShare {
  id: string;
  userName: string;
  userEmail: string;
  shares: number;
  amount: number;
  requestedAt: Date | string;
}

interface AdminPendingSharesProps {
  pendingShares: PendingShare[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export default function AdminPendingShares({ pendingShares, onApprove, onReject }: AdminPendingSharesProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <Coins className="h-5 w-5" />
          Pending Share Purchases
        </CardTitle>
        <Badge variant="secondary">{pendingShares.length} pending</Badge>
      </CardHeader>
      <CardContent>
        {pendingShares.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No pending share purchase requests.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Shares</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Requested</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingShares.map((share) => (
                <TableRow key={share.id} data-testid={`pending-share-${share.id}`}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{share.userName}</p>
                      <p className="text-sm text-muted-foreground">{share.userEmail}</p>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">{share.shares}</TableCell>
                  <TableCell className="font-mono">{formatPeso(share.amount)}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(share.requestedAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => onApprove(share.id)}
                        data-testid={`button-approve-share-${share.id}`}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => onReject(share.id)}
                        data-testid={`button-reject-share-${share.id}`}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
