import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2, Upload, Save } from "lucide-react";

interface SettingsData {
  id: string;
  systemName: string;
  logoUrl: string | null;
  interestRate: number;
  sharePrice: number;
  loanTermMonths: number;
}

interface AdminSettingsProps {
  settings: SettingsData;
  onUpdateSettings: (data: Partial<SettingsData>) => void;
  isPending: boolean;
}

export default function AdminSettings({ settings, onUpdateSettings, isPending }: AdminSettingsProps) {
  const [systemName, setSystemName] = useState(settings.systemName);
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || "");
  const [interestRate, setInterestRate] = useState((settings.interestRate * 100).toString());
  const [sharePrice, setSharePrice] = useState(settings.sharePrice.toString());
  const [loanTermMonths, setLoanTermMonths] = useState(settings.loanTermMonths.toString());

  useEffect(() => {
    setSystemName(settings.systemName);
    setLogoUrl(settings.logoUrl || "");
    setInterestRate((settings.interestRate * 100).toString());
    setSharePrice(settings.sharePrice.toString());
    setLoanTermMonths(settings.loanTermMonths.toString());
  }, [settings]);

  const handleSave = () => {
    onUpdateSettings({
      systemName,
      logoUrl: logoUrl || null,
      interestRate: parseFloat(interestRate) / 100,
      sharePrice: parseFloat(sharePrice),
      loanTermMonths: parseInt(loanTermMonths),
    });
  };

  const hasChanges = 
    systemName !== settings.systemName ||
    (logoUrl || null) !== settings.logoUrl ||
    parseFloat(interestRate) / 100 !== settings.interestRate ||
    parseFloat(sharePrice) !== settings.sharePrice ||
    parseInt(loanTermMonths) !== settings.loanTermMonths;

  return (
    <div className="space-y-6 max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>System Settings</CardTitle>
          <CardDescription>Configure the system name, logo, and financial parameters</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="systemName">System Name</Label>
            <Input
              id="systemName"
              data-testid="input-system-name"
              value={systemName}
              onChange={(e) => setSystemName(e.target.value)}
              placeholder="Enter system name"
            />
            <p className="text-sm text-muted-foreground">
              This name will be displayed in the header and login page
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="logoUrl">Logo URL</Label>
            <div className="flex gap-2">
              <Input
                id="logoUrl"
                data-testid="input-logo-url"
                value={logoUrl}
                onChange={(e) => setLogoUrl(e.target.value)}
                placeholder="https://example.com/logo.png"
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Enter a URL to an image file (PNG, JPG, or SVG recommended)
            </p>
            {logoUrl && (
              <div className="mt-2 p-4 border rounded-md bg-muted/50">
                <p className="text-sm text-muted-foreground mb-2">Preview:</p>
                <img 
                  src={logoUrl} 
                  alt="Logo preview" 
                  className="max-h-16 object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Financial Settings</CardTitle>
          <CardDescription>Configure interest rates and loan terms</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-6 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="interestRate">Interest Rate (%)</Label>
              <Input
                id="interestRate"
                data-testid="input-interest-rate"
                type="number"
                step="0.1"
                min="0"
                max="100"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Fixed interest rate for loans
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sharePrice">Share Price (PHP)</Label>
              <Input
                id="sharePrice"
                data-testid="input-share-price"
                type="number"
                step="50"
                min="0"
                value={sharePrice}
                onChange={(e) => setSharePrice(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Price per share in Philippine Pesos
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="loanTermMonths">Loan Term (months)</Label>
              <Input
                id="loanTermMonths"
                data-testid="input-loan-term"
                type="number"
                min="1"
                max="60"
                value={loanTermMonths}
                onChange={(e) => setLoanTermMonths(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Default repayment period for loans
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          data-testid="button-save-settings"
          onClick={handleSave}
          disabled={isPending || !hasChanges}
        >
          {isPending ? (
            <Loader2 className="h-4 w-4 animate-spin mr-2" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          Save Settings
        </Button>
      </div>
    </div>
  );
}
