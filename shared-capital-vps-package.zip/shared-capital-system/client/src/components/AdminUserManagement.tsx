import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { formatPeso, formatPercent } from "@/lib/format";
import { Users, Pencil, Trash2 } from "lucide-react";

interface UserData {
  id: string;
  name: string;
  email: string;
  shares: number;
  totalInvested: number;
  ownershipPercent: number;
  hasActiveLoan: boolean;
  isAdmin: boolean;
}

interface AdminUserManagementProps {
  users: UserData[];
  onEditUser: (id: string, data: Partial<UserData>) => void;
  onDeleteUser: (id: string) => void;
}

export default function AdminUserManagement({ users, onEditUser, onDeleteUser }: AdminUserManagementProps) {
  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editShares, setEditShares] = useState(0);

  const openEditModal = (user: UserData) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditEmail(user.email);
    setEditShares(user.shares);
  };

  const handleSave = () => {
    if (editingUser) {
      onEditUser(editingUser.id, {
        name: editName,
        email: editEmail,
        shares: editShares,
        totalInvested: editShares * 500,
      });
      setEditingUser(null);
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <Users className="h-5 w-5" />
            User Management
          </CardTitle>
          <Badge variant="secondary">{users.length} users</Badge>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Shares</TableHead>
                <TableHead>Invested</TableHead>
                <TableHead>Ownership</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id} data-testid={`user-row-${user.id}`}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      {user.isAdmin && <Badge variant="default">Admin</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">{user.shares}</TableCell>
                  <TableCell className="font-mono">{formatPeso(user.totalInvested)}</TableCell>
                  <TableCell className="font-mono">{formatPercent(user.ownershipPercent)}</TableCell>
                  <TableCell>
                    {user.hasActiveLoan ? (
                      <Badge variant="secondary">Has Loan</Badge>
                    ) : (
                      <Badge variant="outline">No Loan</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        size="icon" 
                        variant="ghost"
                        onClick={() => openEditModal(user)}
                        data-testid={`button-edit-user-${user.id}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="icon" 
                        variant="ghost"
                        onClick={() => onDeleteUser(user.id)}
                        disabled={user.isAdmin}
                        data-testid={`button-delete-user-${user.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>Update user information and shares.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                data-testid="input-edit-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                type="email"
                value={editEmail}
                onChange={(e) => setEditEmail(e.target.value)}
                data-testid="input-edit-email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-shares">Shares</Label>
              <Input
                id="edit-shares"
                type="number"
                value={editShares}
                onChange={(e) => setEditShares(parseInt(e.target.value) || 0)}
                data-testid="input-edit-shares"
              />
              <p className="text-sm text-muted-foreground">
                Total invested: {formatPeso(editShares * 500)}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingUser(null)}>Cancel</Button>
            <Button onClick={handleSave} data-testid="button-save-user">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
