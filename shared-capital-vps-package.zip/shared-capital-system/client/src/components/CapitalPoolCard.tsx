import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { formatPeso } from "@/lib/format";
import { Vault, Users, TrendingUp } from "lucide-react";

interface CapitalPoolCardProps {
  totalBalance: number;
  totalShares: number;
  totalInvestors: number;
  activeLoans: number;
  loanedAmount: number;
}

export default function CapitalPoolCard({ 
  totalBalance, 
  totalShares, 
  totalInvestors,
  activeLoans,
  loanedAmount
}: CapitalPoolCardProps) {
  const availableBalance = totalBalance - loanedAmount;
  const utilizationRate = totalBalance > 0 ? (loanedAmount / totalBalance) * 100 : 0;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-4 pb-2">
        <div className="p-3 bg-primary rounded-md">
          <Vault className="h-6 w-6 text-primary-foreground" />
        </div>
        <div>
          <CardTitle className="text-lg font-medium">Capital Pool Overview</CardTitle>
          <p className="text-sm text-muted-foreground">Shared investment fund status</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Pool Balance</p>
            <p className="text-2xl font-semibold font-mono" data-testid="text-pool-balance">{formatPeso(totalBalance)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Available for Loans</p>
            <p className="text-2xl font-semibold font-mono text-chart-2" data-testid="text-available-balance">{formatPeso(availableBalance)}</p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Pool Utilization</span>
            <span className="font-medium">{utilizationRate.toFixed(1)}% loaned out</span>
          </div>
          <Progress value={utilizationRate} className="h-2" />
        </div>

        <div className="grid grid-cols-3 gap-4 pt-2 border-t">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
              <TrendingUp className="h-4 w-4" />
            </div>
            <p className="text-lg font-semibold">{totalShares}</p>
            <p className="text-xs text-muted-foreground">Total Shares</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
              <Users className="h-4 w-4" />
            </div>
            <p className="text-lg font-semibold">{totalInvestors}</p>
            <p className="text-xs text-muted-foreground">Investors</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
              <Vault className="h-4 w-4" />
            </div>
            <p className="text-lg font-semibold">{activeLoans}</p>
            <p className="text-xs text-muted-foreground">Active Loans</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
