import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPeso, formatPercent } from "@/lib/format";
import { TrendingUp } from "lucide-react";

interface Dividend {
  id: string;
  month: string;
  amount: number;
  ownershipPercent: number;
}

interface DividendTableProps {
  dividends: Dividend[];
  totalEarned: number;
}

export default function DividendTable({ dividends, totalEarned }: DividendTableProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Dividend History
        </CardTitle>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Total Earned</p>
          <p className="text-lg font-semibold font-mono text-chart-2" data-testid="total-dividends">{formatPeso(totalEarned)}</p>
        </div>
      </CardHeader>
      <CardContent>
        {dividends.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No dividends earned yet. Dividends are distributed monthly from loan interest.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead>Ownership %</TableHead>
                <TableHead className="text-right">Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dividends.map((div) => (
                <TableRow key={div.id} data-testid={`dividend-row-${div.id}`}>
                  <TableCell className="font-medium">{div.month}</TableCell>
                  <TableCell className="text-muted-foreground">{formatPercent(div.ownershipPercent)}</TableCell>
                  <TableCell className="text-right font-mono font-medium text-chart-2">
                    +{formatPeso(div.amount)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
