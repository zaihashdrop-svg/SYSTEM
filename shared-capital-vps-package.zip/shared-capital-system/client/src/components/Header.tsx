import { useState } from "react";
import { Button } from "@/components/ui/button";
import { formatPercent } from "@/lib/format";
import { Landmark, LogOut, User, Menu, X } from "lucide-react";
import SharePurchaseModal from "./SharePurchaseModal";
import LoanApplicationModal from "./LoanApplicationModal";
import { useSettings } from "@/lib/settings-context";

interface HeaderProps {
  userName: string;
  ownershipPercent: number;
  poolBalance: number;
  hasActiveLoan: boolean;
  onSharePurchase: (shares: number, amount: number) => void;
  onLoanApply: (principal: number) => void;
  onLogout: () => void;
}

export default function Header({ 
  userName, 
  ownershipPercent, 
  poolBalance,
  hasActiveLoan,
  onSharePurchase,
  onLoanApply,
  onLogout 
}: HeaderProps) {
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [loanModalOpen, setLoanModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const settings = useSettings();

  return (
    <>
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            <div className="flex items-center gap-3">
              {settings.logoUrl ? (
                <img 
                  src={settings.logoUrl} 
                  alt={settings.systemName} 
                  className="h-10 object-contain"
                />
              ) : (
                <div className="p-2 bg-primary rounded-md">
                  <Landmark className="h-5 w-5 text-primary-foreground" />
                </div>
              )}
              <div className="hidden sm:block">
                <h1 className="font-semibold">{settings.systemName}</h1>
                <p className="text-xs text-muted-foreground">Shared Investment System</p>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {userName}
                </p>
                <p className="text-xs text-muted-foreground">
                  Ownership: {formatPercent(ownershipPercent)}
                </p>
              </div>

              <div className="flex gap-2">
                <Button onClick={() => setShareModalOpen(true)} data-testid="button-header-buy-shares">
                  Buy Shares
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setLoanModalOpen(true)}
                  disabled={hasActiveLoan}
                  data-testid="button-header-apply-loan"
                >
                  Apply for Loan
                </Button>
              </div>

              <Button variant="ghost" size="icon" onClick={onLogout} data-testid="button-logout">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>

            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t space-y-4">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">{userName}</p>
                  <p className="text-xs text-muted-foreground">
                    Ownership: {formatPercent(ownershipPercent)}
                  </p>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Button onClick={() => { setShareModalOpen(true); setMobileMenuOpen(false); }}>
                  Buy Shares
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => { setLoanModalOpen(true); setMobileMenuOpen(false); }}
                  disabled={hasActiveLoan}
                >
                  Apply for Loan
                </Button>
                <Button variant="ghost" onClick={onLogout} className="justify-start">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          )}
        </div>
      </header>

      <SharePurchaseModal
        open={shareModalOpen}
        onOpenChange={setShareModalOpen}
        currentPoolBalance={poolBalance}
        onPurchase={onSharePurchase}
      />

      <LoanApplicationModal
        open={loanModalOpen}
        onOpenChange={setLoanModalOpen}
        availablePool={poolBalance}
        hasActiveLoan={hasActiveLoan}
        onApply={onLoanApply}
      />
    </>
  );
}
