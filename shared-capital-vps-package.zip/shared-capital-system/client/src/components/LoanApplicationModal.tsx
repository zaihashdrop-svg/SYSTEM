import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { formatPeso, formatPercent } from "@/lib/format";
import { CreditCard, AlertCircle, CheckCircle } from "lucide-react";
import { useSettings } from "@/lib/settings-context";

interface LoanApplicationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  availablePool: number;
  hasActiveLoan: boolean;
  onApply: (principal: number) => void;
}

export default function LoanApplicationModal({ 
  open, 
  onOpenChange, 
  availablePool,
  hasActiveLoan,
  onApply 
}: LoanApplicationModalProps) {
  const [principal, setPrincipal] = useState<number>(0);
  const settings = useSettings();

  const calculations = useMemo(() => {
    const totalInterest = principal * settings.interestRate;
    const monthlyInterest = totalInterest / settings.loanTermMonths;
    const monthlyPrincipal = principal / settings.loanTermMonths;
    const monthlyPayment = monthlyPrincipal + monthlyInterest;
    const totalAmount = principal + totalInterest;

    const schedule = Array.from({ length: settings.loanTermMonths }, (_, i) => ({
      month: i + 1,
      principal: monthlyPrincipal,
      interest: monthlyInterest,
      total: monthlyPayment,
    }));

    return { totalInterest, monthlyPayment, totalAmount, schedule };
  }, [principal, settings.interestRate, settings.loanTermMonths]);

  const isValid = principal > 0 && principal <= availablePool && !hasActiveLoan;

  const handleSubmit = () => {
    if (isValid) {
      onApply(principal);
      setPrincipal(0);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Apply for Loan
          </DialogTitle>
          <DialogDescription>
            Fixed {formatPercent(settings.interestRate * 100)} interest rate with {settings.loanTermMonths}-month term.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {hasActiveLoan && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                You already have an active loan. Please pay it off before applying for a new one.
              </AlertDescription>
            </Alert>
          )}

          <div className="p-3 bg-muted rounded-md flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Available Capital Pool</span>
            <span className="text-lg font-semibold font-mono" data-testid="text-available-pool">{formatPeso(availablePool)}</span>
          </div>

          <div className="space-y-2">
            <Label htmlFor="principal">Loan Amount</Label>
            <Input
              id="principal"
              type="number"
              placeholder="Enter amount"
              value={principal || ''}
              onChange={(e) => setPrincipal(Math.max(0, parseFloat(e.target.value) || 0))}
              max={availablePool}
              disabled={hasActiveLoan}
              className="font-mono"
              data-testid="input-loan-amount"
            />
            {principal > availablePool && (
              <p className="text-sm text-destructive">Amount exceeds available pool</p>
            )}
          </div>

          {principal > 0 && (
            <>
              <div className="p-4 bg-muted rounded-md space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Principal</span>
                  <span className="font-mono">{formatPeso(principal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Interest ({formatPercent(settings.interestRate * 100)})</span>
                  <span className="font-mono">{formatPeso(calculations.totalInterest)}</span>
                </div>
                <div className="flex justify-between border-t pt-3">
                  <span className="font-medium">Total to Repay</span>
                  <span className="font-semibold font-mono" data-testid="text-total-repay">{formatPeso(calculations.totalAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Monthly Payment</span>
                  <span className="font-semibold font-mono text-chart-4" data-testid="text-monthly-payment">{formatPeso(calculations.monthlyPayment)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">{settings.loanTermMonths}-Month Payment Schedule</Label>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Month</TableHead>
                      <TableHead className="text-right">Principal</TableHead>
                      <TableHead className="text-right">Interest</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {calculations.schedule.map((row) => (
                      <TableRow key={row.month}>
                        <TableCell>Month {row.month}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{formatPeso(row.principal)}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{formatPeso(row.interest)}</TableCell>
                        <TableCell className="text-right font-mono text-sm font-medium">{formatPeso(row.total)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </>
          )}

          {isValid && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                You are eligible for this loan. It will be automatically approved upon submission.
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!isValid} data-testid="button-apply-loan">
            Apply for Loan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
