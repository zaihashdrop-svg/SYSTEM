import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { formatPeso, formatPercent } from "@/lib/format";
import { CreditCard, Send, Loader2, CheckCircle2, Clock, ArrowDown } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient, getAuthToken } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/lib/settings-context";

interface LoanBalance {
  loanId: string;
  principal: number;
  totalInterestAccrued: number;
  totalPaid: number;
  remainingBalance: number;
  interestRate: number;
  monthsSinceApproval: number;
  status: string;
}

interface Repayment {
  id: string;
  loanId: string;
  amount: number;
  status: 'pending' | 'verified';
  submittedAt: string;
  verifiedAt: string | null;
}

interface LoanCardProps {
  loanId: string;
  principal: number;
  interestRate: number;
  status: 'active' | 'paid' | 'pending';
}

type PaymentOption = 'this_month' | 'pay_all' | 'custom';

export default function LoanCard({ 
  loanId,
  principal, 
  interestRate,
  status 
}: LoanCardProps) {
  const { toast } = useToast();
  const settings = useSettings();
  const [paymentOption, setPaymentOption] = useState<PaymentOption>('this_month');
  const [customAmount, setCustomAmount] = useState("");

  const { data: balance, isLoading: loadingBalance } = useQuery<LoanBalance>({
    queryKey: ['/api/loans', loanId, 'balance'],
    queryFn: async () => {
      const token = getAuthToken();
      const res = await fetch(`/api/loans/${loanId}/balance`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) throw new Error('Failed to fetch balance');
      return res.json();
    },
    enabled: status === 'active',
  });

  const { data: repayments = [] } = useQuery<Repayment[]>({
    queryKey: ['/api/loans', loanId, 'repayments'],
    queryFn: async () => {
      const token = getAuthToken();
      const res = await fetch(`/api/loans/${loanId}/repayments`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) throw new Error('Failed to fetch repayments');
      return res.json();
    },
    enabled: status === 'active',
  });

  const submitPaymentMutation = useMutation({
    mutationFn: async (amount: number) => {
      const res = await apiRequest('POST', `/api/loans/${loanId}/submit-payment`, { amount });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Submitted",
        description: "Your payment has been submitted and is awaiting admin verification.",
      });
      setCustomAmount("");
      queryClient.invalidateQueries({ queryKey: ['/api/loans', loanId, 'balance'] });
      queryClient.invalidateQueries({ queryKey: ['/api/loans', loanId, 'repayments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    let amount = 0;
    
    if (paymentOption === 'this_month') {
      amount = monthlyPayment;
    } else if (paymentOption === 'pay_all') {
      amount = remainingBalance;
    } else {
      amount = parseFloat(customAmount);
    }
    
    if (amount > 0) {
      submitPaymentMutation.mutate(amount);
    }
  };

  if (status === 'pending') {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Loan Application
          </CardTitle>
          <Badge variant="outline">Pending Approval</Badge>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-muted-foreground">Your loan application for {formatPeso(principal)} is being reviewed.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (status === 'paid') {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Loan
          </CardTitle>
          <Badge variant="secondary">Fully Paid</Badge>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-muted-foreground">Your loan of {formatPeso(principal)} has been fully paid.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const loanTermMonths = settings?.loanTermMonths || 5;
  
  // Interest is ALWAYS applied for the full term (e.g., 5 months at 2% = 10% total)
  const fullTermInterest = principal * interestRate * loanTermMonths;
  const totalInterest = balance?.totalInterestAccrued || fullTermInterest;
  const totalDue = principal + fullTermInterest; // Always include full interest
  const totalPaid = balance?.totalPaid || 0;
  const remainingBalance = balance?.remainingBalance || (totalDue - totalPaid);
  const progress = totalDue > 0 ? (totalPaid / totalDue) * 100 : 0;
  
  // Monthly payment = total due / term months (or remaining if less)
  const monthlyPayment = Math.min(totalDue / loanTermMonths, remainingBalance);
  
  const pendingPayments = repayments.filter(r => r.status === 'pending');
  const verifiedPayments = repayments.filter(r => r.status === 'verified');
  const pendingTotal = pendingPayments.reduce((sum, r) => sum + r.amount, 0);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Active Loan
        </CardTitle>
        <Badge variant="default">Active</Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        {loadingBalance ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <div className="p-4 bg-muted/50 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Principal Borrowed</span>
                <span className="font-mono font-semibold">{formatPeso(principal)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">+ Interest Accrued ({formatPercent(interestRate * 100)}/mo)</span>
                <span className="font-mono font-semibold text-orange-600 dark:text-orange-400">+{formatPeso(totalInterest)}</span>
              </div>
              <div className="border-t pt-2 flex items-center justify-between">
                <span className="text-sm font-medium">Total Amount Due</span>
                <span className="font-mono font-bold text-lg">{formatPeso(totalDue)}</span>
              </div>
            </div>

            <div className="p-4 border rounded-lg space-y-3">
              <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                <ArrowDown className="h-4 w-4" />
                <span className="text-sm font-medium">Payments Made</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Verified Payments</span>
                <span className="font-mono font-semibold text-green-600 dark:text-green-400">-{formatPeso(totalPaid)}</span>
              </div>
              {pendingTotal > 0 && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Pending Verification
                  </span>
                  <span className="font-mono text-yellow-600 dark:text-yellow-400">-{formatPeso(pendingTotal)}</span>
                </div>
              )}
              <div className="border-t pt-2 flex items-center justify-between">
                <span className="font-medium">Remaining Balance</span>
                <span className="font-mono font-bold text-xl text-destructive" data-testid="loan-remaining">{formatPeso(remainingBalance)}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Payment Progress</span>
                <span className="font-medium">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-3" />
              <p className="text-xs text-muted-foreground text-center">
                {formatPeso(totalPaid)} paid of {formatPeso(totalDue)} total
              </p>
            </div>

            {pendingPayments.length > 0 && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-800 rounded-md">
                <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200 flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Pending Payments
                </p>
                <div className="mt-2 space-y-1">
                  {pendingPayments.map((payment) => (
                    <div key={payment.id} className="flex justify-between text-sm">
                      <span className="text-yellow-700 dark:text-yellow-300">
                        {new Date(payment.submittedAt).toLocaleDateString()}
                      </span>
                      <span className="font-mono text-yellow-800 dark:text-yellow-200">
                        {formatPeso(payment.amount)}
                      </span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-2">
                  Waiting for admin to confirm receipt
                </p>
              </div>
            )}

            {verifiedPayments.length > 0 && (
              <div className="p-3 bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-md">
                <p className="text-sm font-medium text-green-800 dark:text-green-200 flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  Recent Verified Payments
                </p>
                <div className="mt-2 space-y-1 max-h-24 overflow-y-auto">
                  {verifiedPayments.slice(-3).map((payment) => (
                    <div key={payment.id} className="flex justify-between text-sm">
                      <span className="text-green-700 dark:text-green-300">
                        {new Date(payment.verifiedAt || payment.submittedAt).toLocaleDateString()}
                      </span>
                      <span className="font-mono text-green-800 dark:text-green-200">
                        {formatPeso(payment.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmitPayment} className="space-y-4 pt-2 border-t">
              <Label className="text-base font-medium">Make a Payment</Label>
              
              <RadioGroup 
                value={paymentOption} 
                onValueChange={(val) => setPaymentOption(val as PaymentOption)}
                className="space-y-2"
              >
                <div className="flex items-center justify-between p-3 border rounded-md hover-elevate cursor-pointer" onClick={() => setPaymentOption('this_month')}>
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="this_month" id="this_month" data-testid="radio-this-month" />
                    <Label htmlFor="this_month" className="cursor-pointer">
                      Pay This Month
                    </Label>
                  </div>
                  <span className="font-mono font-semibold">{formatPeso(monthlyPayment)}</span>
                </div>
                
                <div className="flex items-center justify-between p-3 border rounded-md hover-elevate cursor-pointer" onClick={() => setPaymentOption('pay_all')}>
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="pay_all" id="pay_all" data-testid="radio-pay-all" />
                    <Label htmlFor="pay_all" className="cursor-pointer">
                      Pay All (Full Balance)
                    </Label>
                  </div>
                  <span className="font-mono font-semibold">{formatPeso(remainingBalance)}</span>
                </div>
                
                <div className="p-3 border rounded-md space-y-2" onClick={() => setPaymentOption('custom')}>
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="custom" id="custom" data-testid="radio-custom" />
                    <Label htmlFor="custom" className="cursor-pointer">
                      Custom Amount
                    </Label>
                  </div>
                  {paymentOption === 'custom' && (
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(e.target.value)}
                      onClick={(e) => e.stopPropagation()}
                      onFocus={(e) => e.stopPropagation()}
                      min="1"
                      max={remainingBalance}
                      step="0.01"
                      className="mt-2"
                      autoFocus
                      data-testid="input-custom-amount"
                    />
                  )}
                </div>
              </RadioGroup>

              <Button 
                type="submit" 
                className="w-full"
                disabled={submitPaymentMutation.isPending || (paymentOption === 'custom' && !customAmount)}
                data-testid="button-submit-payment"
              >
                {submitPaymentMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Submit Payment
                  </>
                )}
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                Payment will be pending until admin verifies receipt
              </p>
            </form>
          </>
        )}
      </CardContent>
    </Card>
  );
}
