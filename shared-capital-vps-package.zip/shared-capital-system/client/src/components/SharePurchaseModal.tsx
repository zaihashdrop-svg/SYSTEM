import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatPeso } from "@/lib/format";
import { Coins, Plus, Minus } from "lucide-react";
import { useSettings } from "@/lib/settings-context";

interface SharePurchaseModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentPoolBalance: number;
  onPurchase: (shares: number, amount: number) => void;
}

export default function SharePurchaseModal({ 
  open, 
  onOpenChange, 
  currentPoolBalance,
  onPurchase 
}: SharePurchaseModalProps) {
  const [shares, setShares] = useState(1);
  const settings = useSettings();
  const amount = shares * settings.sharePrice;
  const newPoolBalance = currentPoolBalance + amount;

  const handleIncrement = () => setShares(s => s + 1);
  const handleDecrement = () => setShares(s => Math.max(1, s - 1));

  const handleSubmit = () => {
    onPurchase(shares, amount);
    setShares(1);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Coins className="h-5 w-5" />
            Buy Shares
          </DialogTitle>
          <DialogDescription>
            Each share costs {formatPeso(settings.sharePrice)}. Your investment goes into the shared capital pool.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>Number of Shares</Label>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={handleDecrement}
                disabled={shares <= 1}
                data-testid="button-decrement-shares"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Input
                type="number"
                value={shares}
                onChange={(e) => setShares(Math.max(1, parseInt(e.target.value) || 1))}
                className="text-center font-mono text-lg"
                min={1}
                data-testid="input-shares"
              />
              <Button 
                variant="outline" 
                size="icon" 
                onClick={handleIncrement}
                data-testid="button-increment-shares"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="p-4 bg-muted rounded-md space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Shares</span>
              <span className="font-medium">{shares} x {formatPeso(settings.sharePrice)}</span>
            </div>
            <div className="flex justify-between border-t pt-3">
              <span className="font-medium">Total Amount</span>
              <span className="text-xl font-semibold font-mono" data-testid="text-share-total">{formatPeso(amount)}</span>
            </div>
          </div>

          <div className="text-sm text-muted-foreground">
            <p>Capital pool after purchase: <span className="font-mono font-medium">{formatPeso(newPoolBalance)}</span></p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} data-testid="button-confirm-purchase">
            Confirm Purchase
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
