import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPeso, formatDate } from "@/lib/format";
import { Coins, CreditCard, ArrowDownCircle, TrendingUp } from "lucide-react";

type TransactionType = 'share_purchase' | 'loan_disbursement' | 'repayment' | 'dividend';

interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  date: Date | string;
  description: string;
}

interface TransactionTableProps {
  transactions: Transaction[];
}

const typeConfig: Record<TransactionType, { label: string; icon: typeof Coins; variant: 'default' | 'secondary' | 'outline' | 'destructive' }> = {
  share_purchase: { label: 'Share Purchase', icon: Coins, variant: 'default' },
  loan_disbursement: { label: 'Loan', icon: CreditCard, variant: 'secondary' },
  repayment: { label: 'Repayment', icon: ArrowDownCircle, variant: 'outline' },
  dividend: { label: 'Dividend', icon: TrendingUp, variant: 'default' },
};

export default function TransactionTable({ transactions }: TransactionTableProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium">Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((tx) => {
              const config = typeConfig[tx.type];
              const Icon = config.icon;
              const isPositive = tx.type === 'loan_disbursement' || tx.type === 'dividend';
              return (
                <TableRow key={tx.id} data-testid={`transaction-row-${tx.id}`}>
                  <TableCell className="text-muted-foreground">
                    {formatDate(tx.date)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={config.variant} className="gap-1">
                      <Icon className="h-3 w-3" />
                      {config.label}
                    </Badge>
                  </TableCell>
                  <TableCell>{tx.description}</TableCell>
                  <TableCell className={`text-right font-mono font-medium ${isPositive ? 'text-chart-2' : ''}`}>
                    {isPositive ? '+' : '-'}{formatPeso(Math.abs(tx.amount))}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
