import { useState } from 'react';
import AuthForm from '../AuthForm';
import { useToast } from '@/hooks/use-toast';

export default function AuthFormExample() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const { toast } = useToast();

  // todo: remove mock functionality
  const handleSubmit = (email: string, password: string, name?: string) => {
    toast({
      title: mode === 'login' ? 'Login Attempted' : 'Registration Attempted',
      description: `Email: ${email}${name ? `, Name: ${name}` : ''}`,
    });
  };

  return (
    <AuthForm
      mode={mode}
      onSubmit={handleSubmit}
      onModeChange={setMode}
      isLoading={false}
    />
  );
}
