import CapitalPoolCard from '../CapitalPoolCard';

export default function CapitalPoolCardExample() {
  // todo: remove mock functionality
  return (
    <CapitalPoolCard
      totalBalance={150000}
      totalShares={300}
      totalInvestors={8}
      activeLoans={3}
      loanedAmount={35000}
    />
  );
}
