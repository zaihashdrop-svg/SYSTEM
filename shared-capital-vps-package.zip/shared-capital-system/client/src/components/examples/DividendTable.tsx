import DividendTable from '../DividendTable';

// todo: remove mock functionality
const mockDividends = [
  { id: '1', month: 'December 2024', amount: 90, ownershipPercent: 12.5 },
  { id: '2', month: 'November 2024', amount: 85, ownershipPercent: 11.8 },
  { id: '3', month: 'October 2024', amount: 95, ownershipPercent: 13.2 },
  { id: '4', month: 'September 2024', amount: 80, ownershipPercent: 11.0 },
];

export default function DividendTableExample() {
  return <DividendTable dividends={mockDividends} totalEarned={350} />;
}
