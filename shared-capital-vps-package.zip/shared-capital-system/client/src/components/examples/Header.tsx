import Header from '../Header';
import { useToast } from '@/hooks/use-toast';

export default function HeaderExample() {
  const { toast } = useToast();

  // todo: remove mock functionality
  const handleSharePurchase = (shares: number, amount: number) => {
    toast({ title: "Shares Purchased", description: `Bought ${shares} shares` });
  };

  const handleLoanApply = (principal: number) => {
    toast({ title: "Loan Applied", description: `Applied for ₱${principal.toLocaleString()}` });
  };

  const handleLogout = () => {
    toast({ title: "Logged Out", description: "You have been logged out" });
  };

  return (
    <Header
      userName="Juan dela Cruz"
      ownershipPercent={12.5}
      poolBalance={120000}
      hasActiveLoan={false}
      onSharePurchase={handleSharePurchase}
      onLoanApply={handleLoanApply}
      onLogout={handleLogout}
    />
  );
}
