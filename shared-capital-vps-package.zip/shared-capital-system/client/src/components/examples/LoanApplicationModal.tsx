import { useState } from 'react';
import LoanApplicationModal from '../LoanApplicationModal';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function LoanApplicationModalExample() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const handleApply = (principal: number) => {
    // todo: remove mock functionality
    toast({
      title: "Loan Approved",
      description: `Your loan of ₱${principal.toLocaleString()} has been approved!`,
    });
  };

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} data-testid="button-apply-loan-open">
        Apply for Loan
      </Button>
      <LoanApplicationModal
        open={open}
        onOpenChange={setOpen}
        availablePool={120000}
        hasActiveLoan={false}
        onApply={handleApply}
      />
    </>
  );
}
