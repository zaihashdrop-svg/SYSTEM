import LoanCard from '../LoanCard';

export default function LoanCardExample() {
  return (
    <LoanCard
      principal={10000}
      monthlyPayment={2040}
      remainingMonths={3}
      totalMonths={5}
      nextPaymentDate={new Date('2025-01-15')}
      status="active"
    />
  );
}
