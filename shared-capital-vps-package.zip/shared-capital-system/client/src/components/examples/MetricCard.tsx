import MetricCard from '../MetricCard';
import { Wallet, PieChart, TrendingUp } from 'lucide-react';

export default function MetricCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <MetricCard
        title="Total Invested"
        value="₱15,000.00"
        subtitle="30 shares"
        icon={Wallet}
        iconColor="text-chart-3"
      />
      <MetricCard
        title="Ownership"
        value="12.50%"
        subtitle="of ₱120,000 pool"
        icon={PieChart}
        iconColor="text-chart-1"
      />
      <MetricCard
        title="Total Dividends"
        value="₱450.00"
        subtitle="₱90.00 this month"
        icon={TrendingUp}
        iconColor="text-chart-2"
      />
    </div>
  );
}
