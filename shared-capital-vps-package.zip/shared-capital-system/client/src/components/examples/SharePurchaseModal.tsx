import { useState } from 'react';
import SharePurchaseModal from '../SharePurchaseModal';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function SharePurchaseModalExample() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const handlePurchase = (shares: number, amount: number) => {
    // todo: remove mock functionality
    toast({
      title: "Shares Purchased",
      description: `Successfully purchased ${shares} shares for ₱${amount.toLocaleString()}`,
    });
  };

  return (
    <>
      <Button onClick={() => setOpen(true)} data-testid="button-buy-shares">
        Buy Shares
      </Button>
      <SharePurchaseModal
        open={open}
        onOpenChange={setOpen}
        currentPoolBalance={120000}
        onPurchase={handlePurchase}
      />
    </>
  );
}
