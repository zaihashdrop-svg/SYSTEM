import TransactionTable from '../TransactionTable';

// todo: remove mock functionality
const mockTransactions = [
  { id: '1', type: 'share_purchase' as const, amount: 5000, date: new Date('2024-12-10'), description: 'Purchased 10 shares' },
  { id: '2', type: 'dividend' as const, amount: 90, date: new Date('2024-12-01'), description: 'November dividend' },
  { id: '3', type: 'loan_disbursement' as const, amount: 10000, date: new Date('2024-11-15'), description: 'Loan approved' },
  { id: '4', type: 'repayment' as const, amount: 2040, date: new Date('2024-11-30'), description: 'Month 1 payment' },
];

export default function TransactionTableExample() {
  return <TransactionTable transactions={mockTransactions} />;
}
