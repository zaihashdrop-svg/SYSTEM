import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface SystemSettings {
  id: string;
  systemName: string;
  logoUrl: string | null;
  interestRate: number;
  sharePrice: number;
  loanTermMonths: number;
}

export const defaultSettings: SystemSettings = {
  id: '',
  systemName: 'Shared Capital Loan System',
  logoUrl: null,
  interestRate: 0.02,
  sharePrice: 500,
  loanTermMonths: 5,
};

const SettingsContext = createContext<SystemSettings>(defaultSettings);

export const useSettings = () => useContext(SettingsContext);

interface SettingsProviderProps {
  children: ReactNode;
  refreshKey?: number;
}

export function SettingsProvider({ children, refreshKey = 0 }: SettingsProviderProps) {
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('/api/settings');
        if (response.ok) {
          const data = await response.json();
          setSettings(data);
        }
      } catch (error) {
        console.error('Failed to fetch settings:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSettings();
  }, [refreshKey]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <SettingsContext.Provider value={settings || defaultSettings}>
      {children}
    </SettingsContext.Provider>
  );
}
