import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AdminHeader from "@/components/AdminHeader";
import AdminPendingShares from "@/components/AdminPendingShares";
import AdminPendingLoans from "@/components/AdminPendingLoans";
import AdminPendingPayments from "@/components/AdminPendingPayments";
import AdminUserManagement from "@/components/AdminUserManagement";
import AdminLoanManagement from "@/components/AdminLoanManagement";
import CapitalPoolCard from "@/components/CapitalPoolCard";
import { ClipboardList, Users, CreditCard, Vault, Loader2, Settings, Banknote, Check } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatPeso } from "@/lib/format";
import AdminSettings from "@/components/AdminSettings";

interface AdminDashboardProps {
  onLogout: () => void;
}

interface PendingShare {
  id: string;
  userName: string;
  userEmail: string;
  shares: number;
  amount: number;
  requestedAt: string;
}

interface PendingLoan {
  id: string;
  userName: string;
  userEmail: string;
  principal: number;
  monthlyPayment: number;
  requestedAt: string;
}

interface PendingPayment {
  id: string;
  userName: string;
  userEmail: string;
  amount: number;
  loanPrincipal: number;
  loanBalance: number;
  submittedAt: string;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  shares: number;
  totalInvested: number;
  ownershipPercent: number;
  hasActiveLoan: boolean;
  isAdmin: boolean;
}

interface LoanData {
  id: string;
  userName: string;
  principal: number;
  remainingMonths: number;
  totalMonths: number;
  status: 'active' | 'paid' | 'pending';
}

interface PoolData {
  totalBalance: number;
  totalShares: number;
  totalInvestors: number;
  activeLoans: number;
  loanedAmount: number;
}

interface SettingsData {
  id: string;
  systemName: string;
  logoUrl: string | null;
  interestRate: number;
  sharePrice: number;
  loanTermMonths: number;
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const { toast } = useToast();

  const { data: pendingShares = [], isLoading: loadingShares } = useQuery<PendingShare[]>({
    queryKey: ['/api/shares/pending'],
  });

  const { data: pendingLoans = [], isLoading: loadingLoans } = useQuery<PendingLoan[]>({
    queryKey: ['/api/loans/pending'],
  });

  const { data: pendingPayments = [], isLoading: loadingPayments } = useQuery<PendingPayment[]>({
    queryKey: ['/api/admin/payments/pending'],
  });

  const { data: users = [], isLoading: loadingUsers } = useQuery<UserData[]>({
    queryKey: ['/api/admin/users'],
  });

  const { data: loans = [], isLoading: loadingAllLoans } = useQuery<LoanData[]>({
    queryKey: ['/api/loans/all'],
  });

  const { data: pool } = useQuery<PoolData>({
    queryKey: ['/api/pool'],
  });

  const { data: settings, isLoading: loadingSettings } = useQuery<SettingsData>({
    queryKey: ['/api/settings'],
  });

  const { data: dividendStatus, isLoading: loadingDividendStatus } = useQuery<{
    currentMonth: string;
    alreadyDistributed: boolean;
    distributedAmount: number;
    shareholderCount: number;
    potentialDividend: number;
    activeLoansCount: number;
  }>({
    queryKey: ['/api/admin/dividends/status'],
  });

  const approveShareMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('POST', `/api/shares/${id}/approve`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Share Purchase Approved", description: "The share purchase has been approved and added to the user's account." });
      queryClient.invalidateQueries({ queryKey: ['/api/shares/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pool'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const rejectShareMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('POST', `/api/shares/${id}/reject`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Share Purchase Rejected", description: "The share purchase request has been rejected." });
      queryClient.invalidateQueries({ queryKey: ['/api/shares/pending'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const approveLoanMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('POST', `/api/loans/${id}/approve`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Loan Approved", description: "The loan has been approved and disbursed to the user." });
      queryClient.invalidateQueries({ queryKey: ['/api/loans/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/loans/all'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pool'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const rejectLoanMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('POST', `/api/loans/${id}/reject`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Loan Rejected", description: "The loan application has been rejected." });
      queryClient.invalidateQueries({ queryKey: ['/api/loans/pending'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const verifyPaymentMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('POST', `/api/admin/payments/${id}/verify`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Payment Verified", description: "The payment has been marked as received." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/payments/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/loans/all'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pool'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const editUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<UserData> }) => {
      const res = await apiRequest('PATCH', `/api/admin/users/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "User Updated", description: "User information has been updated successfully." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pool'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('DELETE', `/api/admin/users/${id}`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "User Deleted", description: "The user has been removed from the system." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pool'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const editLoanMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<LoanData> }) => {
      const res = await apiRequest('PATCH', `/api/loans/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Loan Updated", description: "Loan details have been updated successfully." });
      queryClient.invalidateQueries({ queryKey: ['/api/loans/all'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Partial<SettingsData>) => {
      const res = await apiRequest('PATCH', '/api/admin/settings', data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Settings Updated", description: "System settings have been saved successfully." });
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const distributeDividendsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/admin/dividends/distribute');
      return res.json();
    },
    onSuccess: (data) => {
      toast({ 
        title: "Dividends Distributed", 
        description: `Distributed to ${data.shareholderCount} shareholders` 
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/dividends/status'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleApproveShare = (id: string) => approveShareMutation.mutate(id);
  const handleRejectShare = (id: string) => rejectShareMutation.mutate(id);
  const handleApproveLoan = (id: string) => approveLoanMutation.mutate(id);
  const handleRejectLoan = (id: string) => rejectLoanMutation.mutate(id);
  const handleVerifyPayment = (id: string) => verifyPaymentMutation.mutate(id);
  const handleEditUser = (id: string, data: Partial<UserData>) => editUserMutation.mutate({ id, data });
  const handleDeleteUser = (id: string) => deleteUserMutation.mutate(id);
  const handleEditLoan = (id: string, data: Partial<LoanData>) => editLoanMutation.mutate({ id, data });
  const handleUpdateSettings = (data: Partial<SettingsData>) => updateSettingsMutation.mutate(data);

  const isLoading = loadingShares || loadingLoans || loadingPayments || loadingUsers || loadingAllLoans || loadingSettings;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const totalPending = pendingShares.length + pendingLoans.length + pendingPayments.length;

  const formattedPendingShares = pendingShares.map(s => ({
    ...s,
    requestedAt: new Date(s.requestedAt),
  }));

  const formattedPendingLoans = pendingLoans.map(l => ({
    ...l,
    requestedAt: new Date(l.requestedAt),
  }));

  const formattedPendingPayments = pendingPayments.map(p => ({
    ...p,
    submittedAt: new Date(p.submittedAt),
  }));

  const poolData = pool || { totalBalance: 0, totalShares: 0, totalInvestors: 0, activeLoans: 0, loanedAmount: 0 };

  return (
    <div className="min-h-screen bg-background">
      <AdminHeader pendingCount={totalPending} onLogout={onLogout} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="approvals" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
            <TabsTrigger value="approvals" className="gap-2" data-testid="tab-approvals">
              <ClipboardList className="h-4 w-4 hidden sm:block" />
              Approvals
              {totalPending > 0 && <span className="text-xs bg-destructive text-destructive-foreground rounded-full px-1.5">{totalPending}</span>}
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2" data-testid="tab-users">
              <Users className="h-4 w-4 hidden sm:block" />
              Users
            </TabsTrigger>
            <TabsTrigger value="loans" className="gap-2" data-testid="tab-loans">
              <CreditCard className="h-4 w-4 hidden sm:block" />
              Loans
            </TabsTrigger>
            <TabsTrigger value="pool" className="gap-2" data-testid="tab-pool">
              <Vault className="h-4 w-4 hidden sm:block" />
              Pool
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2" data-testid="tab-settings">
              <Settings className="h-4 w-4 hidden sm:block" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="approvals" className="space-y-6">
            <AdminPendingPayments
              pendingPayments={formattedPendingPayments}
              onVerify={handleVerifyPayment}
              isVerifying={verifyPaymentMutation.isPending}
            />
            <AdminPendingShares
              pendingShares={formattedPendingShares}
              onApprove={handleApproveShare}
              onReject={handleRejectShare}
            />
            <AdminPendingLoans
              pendingLoans={formattedPendingLoans}
              onApprove={handleApproveLoan}
              onReject={handleRejectLoan}
            />
          </TabsContent>

          <TabsContent value="users">
            <AdminUserManagement
              users={users}
              onEditUser={handleEditUser}
              onDeleteUser={handleDeleteUser}
            />
          </TabsContent>

          <TabsContent value="loans">
            <AdminLoanManagement
              loans={loans}
              onEditLoan={handleEditLoan}
            />
          </TabsContent>

          <TabsContent value="pool">
            <div className="grid gap-6 max-w-2xl">
              <CapitalPoolCard
                totalBalance={poolData.totalBalance}
                totalShares={poolData.totalShares}
                totalInvestors={poolData.totalInvestors}
                activeLoans={poolData.activeLoans}
                loanedAmount={poolData.loanedAmount}
              />
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-4">
                  <div>
                    <CardTitle className="text-lg font-medium flex items-center gap-2">
                      <Banknote className="h-5 w-5" />
                      Monthly Dividend Distribution
                    </CardTitle>
                    <CardDescription>
                      Distribute monthly interest from active loans to shareholders
                    </CardDescription>
                  </div>
                  {dividendStatus?.alreadyDistributed && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      <Check className="h-3 w-3" />
                      Distributed
                    </Badge>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Current Month</p>
                      <p className="font-medium">{dividendStatus?.currentMonth || '-'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Active Loans</p>
                      <p className="font-medium">{dividendStatus?.activeLoansCount || 0}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">
                        {dividendStatus?.alreadyDistributed ? 'Distributed Amount' : 'Potential Dividend'}
                      </p>
                      <p className="font-medium font-mono">
                        {formatPeso(dividendStatus?.alreadyDistributed 
                          ? dividendStatus.distributedAmount 
                          : dividendStatus?.potentialDividend || 0
                        )}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Shareholders</p>
                      <p className="font-medium">{dividendStatus?.shareholderCount || 0}</p>
                    </div>
                  </div>
                  
                  <Button
                    onClick={() => distributeDividendsMutation.mutate()}
                    disabled={dividendStatus?.alreadyDistributed || dividendStatus?.activeLoansCount === 0 || distributeDividendsMutation.isPending}
                    className="w-full"
                    data-testid="button-distribute-dividends"
                  >
                    {distributeDividendsMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Banknote className="h-4 w-4 mr-2" />
                    )}
                    {dividendStatus?.alreadyDistributed 
                      ? 'Already Distributed This Month' 
                      : 'Distribute Monthly Dividends'
                    }
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            {settings && (
              <AdminSettings
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                isPending={updateSettingsMutation.isPending}
              />
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
