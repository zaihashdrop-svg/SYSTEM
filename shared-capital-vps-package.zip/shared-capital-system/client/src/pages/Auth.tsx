import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import AuthForm from "@/components/AuthForm";
import { setAuthToken } from "@/lib/queryClient";

interface AuthPageProps {
  onLoginSuccess: (isAdmin: boolean) => void;
}

export default function AuthPage({ onLoginSuccess }: AuthPageProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (email: string, password: string, name?: string) => {
    setIsLoading(true);
    
    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const body = mode === 'login' 
        ? { email, password }
        : { name, email, password };
      
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      setAuthToken(data.token);
      const isAdmin = data.user.role === 'admin';

      toast({
        title: mode === 'login' ? 'Welcome back!' : 'Account created!',
        description: isAdmin 
          ? 'Logged in as Administrator.' 
          : mode === 'login' 
            ? 'You have successfully signed in.' 
            : 'Your account has been created. Welcome to the investment pool!',
      });

      onLoginSuccess(isAdmin);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <AuthForm
        mode={mode}
        onSubmit={handleSubmit}
        onModeChange={setMode}
        isLoading={isLoading}
      />
    </div>
  );
}
