import { Wallet, PieChart, TrendingUp, Loader2, CalendarClock } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/Header";
import MetricCard from "@/components/MetricCard";
import LoanCard from "@/components/LoanCard";
import TransactionTable from "@/components/TransactionTable";
import DividendTable from "@/components/DividendTable";
import CapitalPoolCard from "@/components/CapitalPoolCard";
import { formatPeso, formatPercent } from "@/lib/format";

interface DashboardProps {
  onLogout: () => void;
}

interface DashboardData {
  user: { id: string; name: string; email: string; role: string };
  shareAccount: { shares: number; totalInvested: number };
  ownershipPercent: number;
  activeLoan: {
    id: string;
    principal: number;
    interestRate: number;
    status: string;
  } | null;
  dividends: Array<{
    id: string;
    month: string;
    amount: number;
    ownershipPercent: number;
  }>;
  transactions: Array<{
    id: string;
    type: string;
    amount: number;
    createdAt: string;
    description: string;
  }>;
  pool: {
    totalBalance: number;
    totalShares: number;
  };
  estimatedMonthlyDividend: number;
  totalActiveLoansInterest: number;
}

interface PoolData {
  totalBalance: number;
  totalShares: number;
  totalInvestors: number;
  activeLoans: number;
  loanedAmount: number;
  availableBalance: number;
}

export default function Dashboard({ onLogout }: DashboardProps) {
  const { toast } = useToast();

  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: ['/api/auth/me'],
  });

  const { data: poolData } = useQuery<PoolData>({
    queryKey: ['/api/pool'],
  });

  const shareRequestMutation = useMutation({
    mutationFn: async (shares: number) => {
      const res = await apiRequest('POST', '/api/shares/request', { shares });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Share Request Submitted",
        description: "Your share purchase request has been submitted for admin approval.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const loanApplyMutation = useMutation({
    mutationFn: async (principal: number) => {
      const res = await apiRequest('POST', '/api/loans/apply', { principal });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Loan Application Submitted",
        description: "Your loan application has been submitted for admin approval.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSharePurchase = (shares: number, amount: number) => {
    shareRequestMutation.mutate(shares);
  };

  const handleLoanApply = (principal: number) => {
    loanApplyMutation.mutate(principal);
  };

  if (isLoading || !dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const { user, shareAccount, ownershipPercent, activeLoan, dividends, transactions, estimatedMonthlyDividend = 0 } = dashboardData;
  const pool = poolData || { totalBalance: 0, totalShares: 0, totalInvestors: 0, activeLoans: 0, loanedAmount: 0, availableBalance: 0 };

  const totalDividends = dividends.reduce((sum, d) => sum + d.amount, 0);
  const currentMonthDividend = dividends[0]?.amount || 0;
  const hasActiveLoan = !!activeLoan && (activeLoan.status === 'active' || activeLoan.status === 'pending');

  const formattedTransactions = transactions.map(t => ({
    id: t.id,
    type: t.type as 'share_purchase' | 'dividend' | 'loan_disbursement' | 'repayment',
    amount: t.amount,
    date: new Date(t.createdAt),
    description: t.description,
  }));

  const formattedDividends = dividends.map(d => ({
    id: d.id,
    month: d.month,
    amount: d.amount,
    ownershipPercent: d.ownershipPercent,
  }));

  return (
    <div className="min-h-screen bg-background">
      <Header
        userName={user.name}
        ownershipPercent={ownershipPercent}
        poolBalance={pool.availableBalance || (pool.totalBalance - pool.loanedAmount)}
        hasActiveLoan={hasActiveLoan}
        onSharePurchase={handleSharePurchase}
        onLoanApply={handleLoanApply}
        onLogout={onLogout}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <section>
            <h2 className="text-xl font-semibold mb-4">Your Investment</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="Total Invested"
                value={formatPeso(shareAccount.totalInvested)}
                subtitle={`${shareAccount.shares} shares`}
                icon={Wallet}
                iconColor="text-chart-3"
              />
              <MetricCard
                title="Ownership"
                value={formatPercent(ownershipPercent)}
                subtitle={`of ${formatPeso(pool.totalBalance)} pool`}
                icon={PieChart}
                iconColor="text-chart-1"
              />
              <MetricCard
                title="Est. Monthly Dividend"
                value={formatPeso(estimatedMonthlyDividend)}
                subtitle="from active loans"
                icon={CalendarClock}
                iconColor="text-chart-4"
              />
              <MetricCard
                title="Total Dividends"
                value={formatPeso(totalDividends)}
                subtitle={`${formatPeso(currentMonthDividend)} this month`}
                icon={TrendingUp}
                iconColor="text-chart-2"
              />
            </div>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <section>
              <h2 className="text-xl font-semibold mb-4">Loan Status</h2>
              {activeLoan ? (
                <LoanCard
                  loanId={activeLoan.id}
                  principal={activeLoan.principal}
                  interestRate={activeLoan.interestRate}
                  status={activeLoan.status === 'paid' ? 'paid' : activeLoan.status === 'pending' ? 'pending' : 'active'}
                />
              ) : (
                <div className="border rounded-md p-8 text-center text-muted-foreground" data-testid="no-loan-message">
                  No active loan. You can apply for a loan using the button above.
                </div>
              )}
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Capital Pool</h2>
              <CapitalPoolCard
                totalBalance={pool.totalBalance}
                totalShares={pool.totalShares}
                totalInvestors={pool.totalInvestors}
                activeLoans={pool.activeLoans}
                loanedAmount={pool.loanedAmount}
              />
            </section>
          </div>

          <section>
            <DividendTable dividends={formattedDividends} totalEarned={totalDividends} />
          </section>

          <section>
            <TransactionTable transactions={formattedTransactions} />
          </section>
        </div>
      </main>
    </div>
  );
}
