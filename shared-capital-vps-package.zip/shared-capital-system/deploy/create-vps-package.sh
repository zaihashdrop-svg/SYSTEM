#!/bin/bash

# Create VPS Deployment Package
# Run this script to create a zip file ready for VPS deployment

set -e

PACKAGE_NAME="shared-capital-vps-deploy"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_DIR="vps-package"

echo "Creating VPS deployment package..."

# Create output directory
rm -rf "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR/$PACKAGE_NAME"

# Copy application files (excluding unnecessary files)
rsync -av --progress \
    --exclude 'node_modules' \
    --exclude '.git' \
    --exclude '.env' \
    --exclude 'dist' \
    --exclude 'vps-package' \
    --exclude '*.log' \
    --exclude '.replit' \
    --exclude 'replit.nix' \
    --exclude '.upm' \
    --exclude '.cache' \
    --exclude '.config' \
    --exclude 'attached_assets' \
    --exclude 'replit.md' \
    ./ "$OUTPUT_DIR/$PACKAGE_NAME/"

# Copy deploy scripts to root of package
cp deploy/install.sh "$OUTPUT_DIR/$PACKAGE_NAME/"
cp deploy/start.sh "$OUTPUT_DIR/$PACKAGE_NAME/"

# Make scripts executable
chmod +x "$OUTPUT_DIR/$PACKAGE_NAME/install.sh"
chmod +x "$OUTPUT_DIR/$PACKAGE_NAME/start.sh"
chmod +x "$OUTPUT_DIR/$PACKAGE_NAME/deploy/"*.sh

# Create the zip file
cd "$OUTPUT_DIR"
zip -r "../${PACKAGE_NAME}_${TIMESTAMP}.zip" "$PACKAGE_NAME"
cd ..

echo ""
echo "=========================================="
echo "Package created successfully!"
echo "=========================================="
echo ""
echo "Output file: ${PACKAGE_NAME}_${TIMESTAMP}.zip"
echo ""
echo "To deploy:"
echo "  1. Upload zip to your VPS"
echo "  2. unzip ${PACKAGE_NAME}_${TIMESTAMP}.zip"
echo "  3. cd $PACKAGE_NAME"
echo "  4. ./install.sh"
echo ""

# Cleanup
rm -rf "$OUTPUT_DIR"
