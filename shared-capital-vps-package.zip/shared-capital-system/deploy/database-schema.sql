-- Shared Capital Loan System - PostgreSQL Database Schema
-- Run this SQL to manually create all database tables
-- Alternative: Use 'npm run db:push' for automatic schema sync

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create ENUM types
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('user', 'admin');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE loan_status AS ENUM ('pending', 'active', 'paid', 'rejected');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE repayment_status AS ENUM ('pending', 'verified');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE share_request_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE transaction_type AS ENUM ('share_purchase', 'loan_disbursement', 'repayment', 'dividend');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role user_role NOT NULL DEFAULT 'user'
);

-- Share accounts table (tracks shares per user)
CREATE TABLE IF NOT EXISTS share_accounts (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    user_id VARCHAR NOT NULL REFERENCES users(id),
    shares INTEGER NOT NULL DEFAULT 0,
    total_invested REAL NOT NULL DEFAULT 0
);

-- Share purchase requests (pending admin approval)
CREATE TABLE IF NOT EXISTS share_requests (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    user_id VARCHAR NOT NULL REFERENCES users(id),
    shares INTEGER NOT NULL,
    amount REAL NOT NULL,
    status share_request_status NOT NULL DEFAULT 'pending',
    requested_at TIMESTAMP NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMP
);

-- Capital pool (singleton - total system balance)
CREATE TABLE IF NOT EXISTS capital_pool (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    total_shares INTEGER NOT NULL DEFAULT 0,
    total_balance REAL NOT NULL DEFAULT 0
);

-- Loans table
CREATE TABLE IF NOT EXISTS loans (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    user_id VARCHAR NOT NULL REFERENCES users(id),
    principal REAL NOT NULL,
    interest_rate REAL NOT NULL DEFAULT 0.02,
    term_months INTEGER NOT NULL DEFAULT 5,
    remaining_months INTEGER NOT NULL DEFAULT 5,
    total_paid REAL NOT NULL DEFAULT 0,
    total_interest_accrued REAL NOT NULL DEFAULT 0,
    last_interest_date TIMESTAMP,
    status loan_status NOT NULL DEFAULT 'pending',
    requested_at TIMESTAMP NOT NULL DEFAULT NOW(),
    approved_at TIMESTAMP
);

-- Repayments table
CREATE TABLE IF NOT EXISTS repayments (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    loan_id VARCHAR NOT NULL REFERENCES loans(id),
    amount REAL NOT NULL,
    principal_amount REAL NOT NULL DEFAULT 0,
    interest_amount REAL NOT NULL DEFAULT 0,
    due_date TIMESTAMP NOT NULL DEFAULT NOW(),
    status repayment_status NOT NULL DEFAULT 'pending',
    submitted_at TIMESTAMP NOT NULL DEFAULT NOW(),
    verified_at TIMESTAMP,
    paid_at TIMESTAMP
);

-- Dividends table (monthly distributions)
CREATE TABLE IF NOT EXISTS dividends (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    user_id VARCHAR NOT NULL REFERENCES users(id),
    month TEXT NOT NULL,
    amount REAL NOT NULL,
    ownership_percent REAL NOT NULL,
    distributed_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Transactions table (audit log)
CREATE TABLE IF NOT EXISTS transactions (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    type transaction_type NOT NULL,
    user_id VARCHAR NOT NULL REFERENCES users(id),
    amount REAL NOT NULL,
    description TEXT NOT NULL,
    reference_id VARCHAR,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- System settings table
CREATE TABLE IF NOT EXISTS system_settings (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::VARCHAR,
    system_name TEXT NOT NULL DEFAULT 'Shared Capital Loan System',
    logo_url TEXT,
    interest_rate REAL NOT NULL DEFAULT 0.02,
    share_price REAL NOT NULL DEFAULT 500,
    loan_term_months INTEGER NOT NULL DEFAULT 5
);

-- Initialize capital pool if empty
INSERT INTO capital_pool (id, total_shares, total_balance)
SELECT gen_random_uuid()::VARCHAR, 0, 0
WHERE NOT EXISTS (SELECT 1 FROM capital_pool);

-- Initialize system settings if empty
INSERT INTO system_settings (id, system_name, interest_rate, share_price, loan_term_months)
SELECT gen_random_uuid()::VARCHAR, 'Shared Capital Loan System', 0.02, 500, 5
WHERE NOT EXISTS (SELECT 1 FROM system_settings);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_share_accounts_user ON share_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_share_requests_user ON share_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_share_requests_status ON share_requests(status);
CREATE INDEX IF NOT EXISTS idx_loans_user ON loans(user_id);
CREATE INDEX IF NOT EXISTS idx_loans_status ON loans(status);
CREATE INDEX IF NOT EXISTS idx_repayments_loan ON repayments(loan_id);
CREATE INDEX IF NOT EXISTS idx_repayments_status ON repayments(status);
CREATE INDEX IF NOT EXISTS idx_dividends_user ON dividends(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);

-- Grant necessary permissions (adjust 'app_user' to your database user)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO app_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;

COMMENT ON TABLE users IS 'User accounts with authentication credentials';
COMMENT ON TABLE share_accounts IS 'Tracks shares owned by each user';
COMMENT ON TABLE share_requests IS 'Pending share purchase requests requiring admin approval';
COMMENT ON TABLE capital_pool IS 'Singleton table tracking total pool balance and shares';
COMMENT ON TABLE loans IS 'Loan records with status workflow';
COMMENT ON TABLE repayments IS 'Individual loan payment records';
COMMENT ON TABLE dividends IS 'Monthly dividend distributions to investors';
COMMENT ON TABLE transactions IS 'Audit log of all financial movements';
COMMENT ON TABLE system_settings IS 'Configurable system parameters';
