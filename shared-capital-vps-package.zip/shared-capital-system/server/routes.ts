import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage, IStorage } from "./storage";
import { authMiddleware, adminMiddleware, generateToken, verifyPassword, type AuthRequest } from "./auth";
import { registerUserSchema, loginSchema, insertShareRequestSchema, insertLoanSchema } from "@shared/schema";

// Helper function to distribute dividends to all shareholders based on their share ownership
async function distributeDividends(storage: IStorage, interestAmount: number, loanId: string) {
  const pool = await storage.getCapitalPool();
  if (pool.totalShares === 0) return;
  
  // Get all share accounts with shares > 0
  const shareAccounts = await storage.getAllShareAccounts();
  const activeShareholders = shareAccounts.filter(sa => sa.shares > 0);
  
  if (activeShareholders.length === 0) return;
  
  const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
  
  for (const account of activeShareholders) {
    const ownershipPercent = (account.shares / pool.totalShares) * 100;
    const dividendAmount = (interestAmount * account.shares) / pool.totalShares;
    
    // Create dividend record
    await storage.createDividend(account.userId, currentMonth, dividendAmount, ownershipPercent);
    
    // Create transaction record
    await storage.createTransaction(
      'dividend',
      account.userId,
      dividendAmount,
      `Dividend from loan interest (${ownershipPercent.toFixed(1)}% ownership)`,
      loanId
    );
  }
}

// Helper function to distribute monthly dividends from active loans
async function distributeMonthlyDividends(storage: IStorage, month: string): Promise<{ distributed: boolean; totalAmount: number; shareholderCount: number }> {
  const pool = await storage.getCapitalPool();
  if (pool.totalShares === 0) return { distributed: false, totalAmount: 0, shareholderCount: 0 };
  
  // Check if MONTHLY dividends for this month already distributed
  // Use a special marker format: "MONTHLY-YYYY-MM" in description to differentiate from loan-completion dividends
  const existingDividends = await storage.getDividendsByMonth(`MONTHLY-${month}`);
  if (existingDividends.length > 0) {
    return { distributed: false, totalAmount: 0, shareholderCount: 0 };
  }
  
  // Get all active loans and calculate monthly interest using each loan's stored rate
  const allLoans = await storage.getAllLoans();
  const activeLoans = allLoans.filter(l => l.status === 'active');
  
  if (activeLoans.length === 0) return { distributed: false, totalAmount: 0, shareholderCount: 0 };
  
  // Monthly interest = principal × loan's interest rate (per month) - use loan's own rate
  const totalMonthlyInterest = activeLoans.reduce((sum, loan) => {
    return sum + (loan.principal * loan.interestRate);
  }, 0);
  
  // Get all share accounts with shares > 0
  const shareAccounts = await storage.getAllShareAccounts();
  const activeShareholders = shareAccounts.filter(sa => sa.shares > 0);
  
  if (activeShareholders.length === 0) return { distributed: false, totalAmount: 0, shareholderCount: 0 };
  
  for (const account of activeShareholders) {
    const ownershipPercent = (account.shares / pool.totalShares) * 100;
    const dividendAmount = (totalMonthlyInterest * account.shares) / pool.totalShares;
    
    // Create dividend record with MONTHLY- prefix to distinguish from loan-completion dividends
    await storage.createDividend(account.userId, `MONTHLY-${month}`, dividendAmount, ownershipPercent);
    
    // Create transaction record
    await storage.createTransaction(
      'dividend',
      account.userId,
      dividendAmount,
      `Monthly dividend for ${month} (${ownershipPercent.toFixed(1)}% ownership)`,
      undefined
    );
  }
  
  return { 
    distributed: true, 
    totalAmount: totalMonthlyInterest, 
    shareholderCount: activeShareholders.length 
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ===== AUTH ROUTES =====
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }

      const user = await storage.createUser(data);
      const token = generateToken(user);
      
      res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const validPassword = await verifyPassword(data.password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const token = generateToken(user);
      res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Login failed" });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: AuthRequest, res) => {
    const user = req.user!;
    const shareAccount = await storage.getShareAccount(user.id);
    const pool = await storage.getCapitalPool();
    const activeLoan = await storage.getActiveLoanByUser(user.id);
    const dividends = await storage.getDividendsByUser(user.id);
    const transactions = await storage.getTransactionsByUser(user.id);
    const settings = await storage.getSettings();

    const ownershipPercent = pool.totalShares > 0 
      ? ((shareAccount?.shares || 0) / pool.totalShares) * 100 
      : 0;

    // Calculate estimated monthly dividend from active loans
    const allLoans = await storage.getAllLoans();
    const activeLoans = allLoans.filter(l => l.status === 'active');
    
    // Monthly interest = principal × each loan's interest rate (per month)
    const totalMonthlyInterest = activeLoans.reduce((sum, loan) => {
      return sum + (loan.principal * loan.interestRate);
    }, 0);
    
    // User's estimated monthly dividend based on ownership
    const estimatedMonthlyDividend = totalMonthlyInterest * (ownershipPercent / 100);

    res.json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      shareAccount: shareAccount || { shares: 0, totalInvested: 0 },
      ownershipPercent,
      activeLoan,
      dividends,
      transactions,
      pool,
      estimatedMonthlyDividend,
      totalActiveLoansInterest: totalMonthlyInterest,
    });
  });

  // ===== SHARE ROUTES =====
  app.post("/api/shares/request", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertShareRequestSchema.parse(req.body);
      const settings = await storage.getSettings();
      const amount = data.shares * settings.sharePrice;
      
      const request = await storage.createShareRequest(req.user!.id, data.shares, amount);
      res.json(request);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to create share request" });
    }
  });

  app.get("/api/shares/pending", authMiddleware, adminMiddleware, async (req, res) => {
    const requests = await storage.getPendingShareRequests();
    
    // Enrich with user data
    const enriched = await Promise.all(requests.map(async (r) => {
      const user = await storage.getUserById(r.userId);
      return { ...r, userName: user?.name, userEmail: user?.email };
    }));
    
    res.json(enriched);
  });

  app.post("/api/shares/:id/approve", authMiddleware, adminMiddleware, async (req, res) => {
    const request = await storage.approveShareRequest(req.params.id);
    if (!request) {
      return res.status(404).json({ error: "Share request not found" });
    }
    res.json(request);
  });

  app.post("/api/shares/:id/reject", authMiddleware, adminMiddleware, async (req, res) => {
    const request = await storage.rejectShareRequest(req.params.id);
    if (!request) {
      return res.status(404).json({ error: "Share request not found" });
    }
    res.json(request);
  });

  // ===== LOAN ROUTES =====
  app.post("/api/loans/apply", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertLoanSchema.parse(req.body);
      
      // Check for existing active loan
      const activeLoan = await storage.getActiveLoanByUser(req.user!.id);
      if (activeLoan) {
        return res.status(400).json({ error: "You already have an active loan" });
      }

      // Check if amount is within available pool
      const pool = await storage.getCapitalPool();
      const allLoans = await storage.getAllLoans();
      const loanedAmount = allLoans
        .filter(l => l.status === 'active')
        .reduce((sum, l) => sum + l.principal, 0);
      const availableBalance = pool.totalBalance - loanedAmount;

      if (data.principal > availableBalance) {
        return res.status(400).json({ error: "Loan amount exceeds available pool balance" });
      }

      const loan = await storage.createLoan(req.user!.id, data.principal);
      res.json(loan);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to apply for loan" });
    }
  });

  app.get("/api/loans/pending", authMiddleware, adminMiddleware, async (req, res) => {
    const loans = await storage.getPendingLoans();
    const settings = await storage.getSettings();
    
    const enriched = await Promise.all(loans.map(async (l) => {
      const user = await storage.getUserById(l.userId);
      const monthlyPayment = (l.principal / settings.loanTermMonths) + ((l.principal * settings.interestRate) / settings.loanTermMonths);
      return { ...l, userName: user?.name, userEmail: user?.email, monthlyPayment };
    }));
    
    res.json(enriched);
  });

  app.get("/api/loans/all", authMiddleware, adminMiddleware, async (req, res) => {
    const loans = await storage.getAllLoans();
    
    const enriched = await Promise.all(loans.map(async (l) => {
      const user = await storage.getUserById(l.userId);
      return { ...l, userName: user?.name };
    }));
    
    res.json(enriched);
  });

  app.get("/api/loans/:id/repayments", authMiddleware, async (req: AuthRequest, res) => {
    const loan = await storage.getLoanById(req.params.id);
    if (!loan) {
      return res.status(404).json({ error: "Loan not found" });
    }
    
    // Check ownership or admin
    if (loan.userId !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: "Access denied" });
    }

    const repayments = await storage.getRepaymentsByLoan(loan.id);
    res.json(repayments);
  });

  app.post("/api/loans/:id/approve", authMiddleware, adminMiddleware, async (req, res) => {
    const loan = await storage.approveLoan(req.params.id);
    if (!loan) {
      return res.status(404).json({ error: "Loan not found" });
    }
    res.json(loan);
  });

  app.post("/api/loans/:id/reject", authMiddleware, adminMiddleware, async (req, res) => {
    const loan = await storage.rejectLoan(req.params.id);
    if (!loan) {
      return res.status(404).json({ error: "Loan not found" });
    }
    res.json(loan);
  });

  app.patch("/api/loans/:id", authMiddleware, adminMiddleware, async (req, res) => {
    const loan = await storage.updateLoan(req.params.id, req.body);
    if (!loan) {
      return res.status(404).json({ error: "Loan not found" });
    }
    res.json(loan);
  });

  // User submits a payment for verification
  app.post("/api/loans/:id/submit-payment", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const loan = await storage.getLoanById(req.params.id);
      if (!loan) {
        return res.status(404).json({ error: "Loan not found" });
      }
      
      if (loan.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      if (loan.status !== 'active') {
        return res.status(400).json({ error: "Loan is not active" });
      }
      
      const { amount } = req.body;
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: "Invalid payment amount" });
      }
      
      // Calculate how much goes to principal vs interest
      const remainingBalance = loan.principal + loan.totalInterestAccrued - loan.totalPaid;
      const interestPortion = Math.min(amount, loan.totalInterestAccrued);
      const principalPortion = amount - interestPortion;
      
      const repayment = await storage.createRepayment(loan.id, amount, principalPortion, interestPortion);
      res.json(repayment);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to submit payment" });
    }
  });

  // Admin gets all pending payments
  app.get("/api/admin/payments/pending", authMiddleware, adminMiddleware, async (req, res) => {
    const pendingPayments = await storage.getPendingPayments();
    
    const enriched = await Promise.all(pendingPayments.map(async (p) => {
      const loan = await storage.getLoanById(p.loanId);
      const user = loan ? await storage.getUserById(loan.userId) : null;
      return {
        ...p,
        userName: user?.name,
        userEmail: user?.email,
        loanPrincipal: loan?.principal,
        loanBalance: loan ? (loan.principal + loan.totalInterestAccrued - loan.totalPaid) : 0,
      };
    }));
    
    res.json(enriched);
  });

  // Admin verifies/receives a payment
  app.post("/api/admin/payments/:id/verify", authMiddleware, adminMiddleware, async (req, res) => {
    try {
      const repayment = await storage.verifyPayment(req.params.id);
      if (!repayment) {
        return res.status(404).json({ error: "Payment not found" });
      }
      
      // Update the loan's totalPaid
      const loan = await storage.getLoanById(repayment.loanId);
      if (loan) {
        // Get settings for loan term to calculate full interest
        const settings = await storage.getSettings();
        const loanTermMonths = settings?.loanTermMonths || 5;
        const fullTermInterest = loan.principal * loan.interestRate * loanTermMonths;
        
        const newTotalPaid = loan.totalPaid + repayment.amount;
        const totalDue = loan.principal + fullTermInterest;
        const isFullyPaid = newTotalPaid >= totalDue;
        
        await storage.updateLoan(loan.id, { 
          totalPaid: newTotalPaid,
          status: isFullyPaid ? 'paid' : loan.status
        });
        
        // Return payment to pool
        const pool = await storage.getCapitalPool();
        await storage.updateCapitalPool(pool.totalShares, pool.totalBalance + repayment.amount);
        
        // Create transaction
        await storage.createTransaction(
          'repayment',
          loan.userId,
          repayment.amount,
          `Loan payment verified`,
          repayment.id
        );
        
        // If loan is fully paid, distribute the full term interest as dividends to shareholders
        if (isFullyPaid && fullTermInterest > 0) {
          await distributeDividends(storage, fullTermInterest, loan.id);
        }
      }
      
      res.json(repayment);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to verify payment" });
    }
  });

  // Get loan balance details (calculates current balance with interest)
  app.get("/api/loans/:id/balance", authMiddleware, async (req: AuthRequest, res) => {
    const loan = await storage.getLoanById(req.params.id);
    if (!loan) {
      return res.status(404).json({ error: "Loan not found" });
    }
    
    if (loan.userId !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: "Access denied" });
    }
    
    // Get settings for loan term
    const settings = await storage.getSettings();
    const loanTermMonths = settings?.loanTermMonths || 5;
    
    // Interest is ALWAYS applied for full term (e.g., 5 months at 2% = 10% total interest)
    // This means even if they pay early, they still pay full interest
    const fullTermInterest = loan.principal * loan.interestRate * loanTermMonths;
    const totalDue = loan.principal + fullTermInterest;
    const remainingBalance = totalDue - loan.totalPaid;
    
    res.json({
      loanId: loan.id,
      principal: loan.principal,
      totalInterestAccrued: fullTermInterest,
      totalPaid: loan.totalPaid,
      remainingBalance: Math.max(0, remainingBalance),
      interestRate: loan.interestRate,
      termMonths: loanTermMonths,
      status: loan.status,
    });
  });

  // ===== MONTHLY DIVIDEND DISTRIBUTION =====
  app.post("/api/admin/dividends/distribute", authMiddleware, adminMiddleware, async (req, res) => {
    try {
      // Use current month or specified month
      const month = req.body.month || new Date().toISOString().slice(0, 7);
      
      const result = await distributeMonthlyDividends(storage, month);
      
      if (!result.distributed) {
        return res.status(400).json({ 
          error: "Dividends already distributed for this month or no active loans",
          month 
        });
      }
      
      res.json({
        success: true,
        month,
        totalAmount: result.totalAmount,
        shareholderCount: result.shareholderCount,
        message: `Distributed dividends to ${result.shareholderCount} shareholders`
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to distribute dividends" });
    }
  });

  // Get dividend distribution status for current month
  app.get("/api/admin/dividends/status", authMiddleware, adminMiddleware, async (req, res) => {
    const currentMonth = new Date().toISOString().slice(0, 7);
    // Check for MONTHLY- prefixed dividends only
    const existingDividends = await storage.getDividendsByMonth(`MONTHLY-${currentMonth}`);
    
    // Calculate potential dividend using each loan's stored rate
    const allLoans = await storage.getAllLoans();
    const activeLoans = allLoans.filter(l => l.status === 'active');
    
    const potentialDividend = activeLoans.reduce((sum, loan) => {
      return sum + (loan.principal * loan.interestRate);
    }, 0);
    
    res.json({
      currentMonth,
      alreadyDistributed: existingDividends.length > 0,
      distributedAmount: existingDividends.reduce((sum, d) => sum + d.amount, 0),
      shareholderCount: new Set(existingDividends.map(d => d.userId)).size,
      potentialDividend,
      activeLoansCount: activeLoans.length,
    });
  });

  // ===== ADMIN USER MANAGEMENT =====
  app.get("/api/admin/users", authMiddleware, adminMiddleware, async (req, res) => {
    const users = await storage.getAllUsers();
    
    const enriched = await Promise.all(users.map(async (u) => {
      const shareAccount = await storage.getShareAccount(u.id);
      const activeLoan = await storage.getActiveLoanByUser(u.id);
      const pool = await storage.getCapitalPool();
      const ownershipPercent = pool.totalShares > 0 
        ? ((shareAccount?.shares || 0) / pool.totalShares) * 100 
        : 0;
      
      return {
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        shares: shareAccount?.shares || 0,
        totalInvested: shareAccount?.totalInvested || 0,
        ownershipPercent,
        hasActiveLoan: !!activeLoan,
        isAdmin: u.role === 'admin',
      };
    }));
    
    res.json(enriched);
  });

  app.patch("/api/admin/users/:id", authMiddleware, adminMiddleware, async (req, res) => {
    const { name, email, shares } = req.body;
    
    // Update user
    if (name || email) {
      await storage.updateUser(req.params.id, { name, email });
    }
    
    // Update shares if provided
    if (shares !== undefined) {
      const settings = await storage.getSettings();
      const account = await storage.getShareAccount(req.params.id);
      if (account) {
        const oldShares = account.shares;
        const shareDiff = shares - oldShares;
        const amountDiff = shareDiff * settings.sharePrice;
        
        await storage.updateShareAccount(req.params.id, shares, account.totalInvested + amountDiff);
        
        // Update pool
        const pool = await storage.getCapitalPool();
        await storage.updateCapitalPool(pool.totalShares + shareDiff, pool.totalBalance + amountDiff);
      }
    }
    
    res.json({ success: true });
  });

  app.delete("/api/admin/users/:id", authMiddleware, adminMiddleware, async (req, res) => {
    const user = await storage.getUserById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    if (user.role === 'admin') {
      return res.status(400).json({ error: "Cannot delete admin user" });
    }
    
    await storage.deleteUser(req.params.id);
    res.json({ success: true });
  });

  // ===== CAPITAL POOL =====
  app.get("/api/pool", authMiddleware, async (req, res) => {
    const pool = await storage.getCapitalPool();
    const loans = await storage.getAllLoans();
    const users = await storage.getAllUsers();
    
    const loanedAmount = loans
      .filter(l => l.status === 'active')
      .reduce((sum, l) => sum + l.principal, 0);
    const activeLoans = loans.filter(l => l.status === 'active').length;
    const totalInvestors = users.filter(u => u.role !== 'admin').length;
    
    res.json({
      ...pool,
      loanedAmount,
      activeLoans,
      totalInvestors,
      availableBalance: pool.totalBalance - loanedAmount,
    });
  });

  // ===== DIVIDENDS =====
  app.get("/api/dividends", authMiddleware, async (req: AuthRequest, res) => {
    const dividends = await storage.getDividendsByUser(req.user!.id);
    res.json(dividends);
  });

  // ===== TRANSACTIONS =====
  app.get("/api/transactions", authMiddleware, async (req: AuthRequest, res) => {
    const transactions = await storage.getTransactionsByUser(req.user!.id);
    res.json(transactions);
  });

  app.get("/api/admin/transactions", authMiddleware, adminMiddleware, async (req, res) => {
    const transactions = await storage.getAllTransactions();
    res.json(transactions);
  });

  // ===== SETTINGS =====
  app.get("/api/settings", async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.patch("/api/admin/settings", authMiddleware, adminMiddleware, async (req, res) => {
    const { systemName, logoUrl, interestRate, sharePrice, loanTermMonths } = req.body;
    
    const updateData: any = {};
    if (systemName !== undefined) updateData.systemName = systemName;
    if (logoUrl !== undefined) updateData.logoUrl = logoUrl;
    if (interestRate !== undefined) updateData.interestRate = interestRate;
    if (sharePrice !== undefined) updateData.sharePrice = sharePrice;
    if (loanTermMonths !== undefined) updateData.loanTermMonths = loanTermMonths;
    
    const settings = await storage.updateSettings(updateData);
    res.json(settings);
  });

  return httpServer;
}
