import { db } from "./db";
import { users, shareAccounts, capitalPool } from "@shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

async function seed() {
  console.log("Seeding database...");

  // Check if admin exists
  const existingAdmin = await db.select().from(users).where(eq(users.email, "admin@example.com"));
  
  if (existingAdmin.length === 0) {
    const hashedPassword = await bcrypt.hash("admin123", 10);
    
    const [admin] = await db.insert(users).values({
      name: "Admin",
      email: "admin@example.com",
      password: hashedPassword,
      role: "admin",
    }).returning();

    // Create share account for admin
    await db.insert(shareAccounts).values({
      userId: admin.id,
      shares: 0,
      totalInvested: 0,
    });

    console.log("Admin user created: admin@example.com / admin123");
  } else {
    console.log("Admin user already exists");
  }

  // Ensure capital pool exists
  const pool = await db.select().from(capitalPool);
  if (pool.length === 0) {
    await db.insert(capitalPool).values({
      totalShares: 0,
      totalBalance: 0,
    });
    console.log("Capital pool initialized");
  } else {
    console.log("Capital pool already exists");
  }

  console.log("Seed complete!");
}

seed().catch(console.error);
