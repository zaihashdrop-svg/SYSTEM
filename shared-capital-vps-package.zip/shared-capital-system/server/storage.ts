import { eq, and, desc, sql, inArray } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  shareAccounts,
  shareRequests,
  capitalPool,
  loans,
  repayments,
  dividends,
  transactions,
  systemSettings,
  type User,
  type InsertUser,
  type ShareAccount,
  type ShareRequest,
  type CapitalPool,
  type Loan,
  type Repayment,
  type Dividend,
  type Transaction,
  type SystemSettings,
  type InsertSettings,
} from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  // Users
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  deleteUser(id: string): Promise<void>;

  // Share Accounts
  getShareAccount(userId: string): Promise<ShareAccount | undefined>;
  getAllShareAccounts(): Promise<ShareAccount[]>;
  createShareAccount(userId: string): Promise<ShareAccount>;
  updateShareAccount(userId: string, shares: number, totalInvested: number): Promise<ShareAccount>;

  // Share Requests
  createShareRequest(userId: string, shares: number, amount: number): Promise<ShareRequest>;
  getPendingShareRequests(): Promise<ShareRequest[]>;
  approveShareRequest(id: string): Promise<ShareRequest | undefined>;
  rejectShareRequest(id: string): Promise<ShareRequest | undefined>;

  // Capital Pool
  getCapitalPool(): Promise<CapitalPool>;
  updateCapitalPool(totalShares: number, totalBalance: number): Promise<CapitalPool>;

  // Loans
  createLoan(userId: string, principal: number): Promise<Loan>;
  getLoanById(id: string): Promise<Loan | undefined>;
  getActiveLoanByUser(userId: string): Promise<Loan | undefined>;
  getPendingLoans(): Promise<Loan[]>;
  getAllLoans(): Promise<Loan[]>;
  approveLoan(id: string): Promise<Loan | undefined>;
  rejectLoan(id: string): Promise<Loan | undefined>;
  updateLoan(id: string, data: Partial<Loan>): Promise<Loan | undefined>;

  // Repayments (flexible payment system)
  createRepayment(loanId: string, amount: number, principalAmount: number, interestAmount: number): Promise<Repayment>;
  getRepaymentsByLoan(loanId: string): Promise<Repayment[]>;
  getPendingPayments(): Promise<Repayment[]>;
  verifyPayment(id: string): Promise<Repayment | undefined>;

  // Dividends
  createDividend(userId: string, month: string, amount: number, ownershipPercent: number): Promise<Dividend>;
  getDividendsByUser(userId: string): Promise<Dividend[]>;
  getDividendsByMonth(month: string): Promise<Dividend[]>;

  // Transactions
  createTransaction(type: string, userId: string, amount: number, description: string, referenceId?: string): Promise<Transaction>;
  getTransactionsByUser(userId: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;

  // Settings
  getSettings(): Promise<SystemSettings>;
  updateSettings(data: Partial<InsertSettings>): Promise<SystemSettings>;
}

class DatabaseStorage implements IStorage {
  // Users
  async createUser(userData: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const [user] = await db
      .insert(users)
      .values({ ...userData, password: hashedPassword })
      .returning();
    
    // Create share account for new user
    await this.createShareAccount(user.id);
    
    return user;
  }

  async getUserById(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return user;
  }

  async deleteUser(id: string): Promise<void> {
    // Get all loans for this user to delete their repayments
    const userLoans = await db.select().from(loans).where(eq(loans.userId, id));
    const loanIds = userLoans.map(l => l.id);
    
    // Delete repayments for user's loans
    if (loanIds.length > 0) {
      await db.delete(repayments).where(inArray(repayments.loanId, loanIds));
    }
    
    // Delete all related records in order (respecting foreign keys)
    await db.delete(dividends).where(eq(dividends.userId, id));
    await db.delete(transactions).where(eq(transactions.userId, id));
    await db.delete(loans).where(eq(loans.userId, id));
    await db.delete(shareRequests).where(eq(shareRequests.userId, id));
    await db.delete(shareAccounts).where(eq(shareAccounts.userId, id));
    
    // Finally delete the user
    await db.delete(users).where(eq(users.id, id));
  }

  // Share Accounts
  async getShareAccount(userId: string): Promise<ShareAccount | undefined> {
    const [account] = await db.select().from(shareAccounts).where(eq(shareAccounts.userId, userId));
    return account;
  }

  async getAllShareAccounts(): Promise<ShareAccount[]> {
    return db.select().from(shareAccounts);
  }

  async createShareAccount(userId: string): Promise<ShareAccount> {
    const [account] = await db.insert(shareAccounts).values({ userId }).returning();
    return account;
  }

  async updateShareAccount(userId: string, shares: number, totalInvested: number): Promise<ShareAccount> {
    const [account] = await db
      .update(shareAccounts)
      .set({ shares, totalInvested })
      .where(eq(shareAccounts.userId, userId))
      .returning();
    return account;
  }

  // Share Requests
  async createShareRequest(userId: string, shares: number, amount: number): Promise<ShareRequest> {
    const [request] = await db.insert(shareRequests).values({ userId, shares, amount }).returning();
    return request;
  }

  async getPendingShareRequests(): Promise<ShareRequest[]> {
    return db.select().from(shareRequests).where(eq(shareRequests.status, 'pending')).orderBy(desc(shareRequests.requestedAt));
  }

  async approveShareRequest(id: string): Promise<ShareRequest | undefined> {
    const [request] = await db
      .update(shareRequests)
      .set({ status: 'approved', processedAt: new Date() })
      .where(eq(shareRequests.id, id))
      .returning();
    
    if (request) {
      // Update share account
      const account = await this.getShareAccount(request.userId);
      if (account) {
        await this.updateShareAccount(
          request.userId,
          account.shares + request.shares,
          account.totalInvested + request.amount
        );
      }

      // Update capital pool
      const pool = await this.getCapitalPool();
      await this.updateCapitalPool(
        pool.totalShares + request.shares,
        pool.totalBalance + request.amount
      );

      // Create transaction
      await this.createTransaction(
        'share_purchase',
        request.userId,
        request.amount,
        `Purchased ${request.shares} shares`,
        request.id
      );
    }

    return request;
  }

  async rejectShareRequest(id: string): Promise<ShareRequest | undefined> {
    const [request] = await db
      .update(shareRequests)
      .set({ status: 'rejected', processedAt: new Date() })
      .where(eq(shareRequests.id, id))
      .returning();
    return request;
  }

  // Capital Pool
  async getCapitalPool(): Promise<CapitalPool> {
    let [pool] = await db.select().from(capitalPool);
    if (!pool) {
      [pool] = await db.insert(capitalPool).values({}).returning();
    }
    return pool;
  }

  async updateCapitalPool(totalShares: number, totalBalance: number): Promise<CapitalPool> {
    const pool = await this.getCapitalPool();
    const [updated] = await db
      .update(capitalPool)
      .set({ totalShares, totalBalance })
      .where(eq(capitalPool.id, pool.id))
      .returning();
    return updated;
  }

  // Loans
  async createLoan(userId: string, principal: number): Promise<Loan> {
    const [loan] = await db.insert(loans).values({ userId, principal }).returning();
    return loan;
  }

  async getLoanById(id: string): Promise<Loan | undefined> {
    const [loan] = await db.select().from(loans).where(eq(loans.id, id));
    return loan;
  }

  async getActiveLoanByUser(userId: string): Promise<Loan | undefined> {
    // Returns the most recent active or pending loan
    const [loan] = await db
      .select()
      .from(loans)
      .where(and(
        eq(loans.userId, userId), 
        sql`${loans.status} IN ('active', 'pending')`
      ))
      .orderBy(desc(loans.requestedAt));
    return loan;
  }

  async getPendingLoans(): Promise<Loan[]> {
    return db.select().from(loans).where(eq(loans.status, 'pending')).orderBy(desc(loans.requestedAt));
  }

  async getAllLoans(): Promise<Loan[]> {
    return db.select().from(loans).orderBy(desc(loans.requestedAt));
  }

  async approveLoan(id: string): Promise<Loan | undefined> {
    const settings = await this.getSettings();
    const now = new Date();
    const [loan] = await db
      .update(loans)
      .set({ 
        status: 'active', 
        approvedAt: now,
        interestRate: settings.interestRate,
        termMonths: settings.loanTermMonths,
        remainingMonths: settings.loanTermMonths,
        totalPaid: 0,
        totalInterestAccrued: 0,
        lastInterestDate: now
      })
      .where(eq(loans.id, id))
      .returning();

    if (loan) {
      // Create transaction for loan disbursement
      await this.createTransaction(
        'loan_disbursement',
        loan.userId,
        loan.principal,
        `Loan approved - ${loan.principal} disbursed`,
        loan.id
      );
    }

    return loan;
  }

  async rejectLoan(id: string): Promise<Loan | undefined> {
    const [loan] = await db
      .update(loans)
      .set({ status: 'rejected' })
      .where(eq(loans.id, id))
      .returning();
    return loan;
  }

  async updateLoan(id: string, data: Partial<Loan>): Promise<Loan | undefined> {
    const [loan] = await db.update(loans).set(data).where(eq(loans.id, id)).returning();
    return loan;
  }

  // Repayments (flexible payment system)
  async createRepayment(loanId: string, amount: number, principalAmount: number, interestAmount: number): Promise<Repayment> {
    const [repayment] = await db
      .insert(repayments)
      .values({ 
        loanId, 
        amount,
        principalAmount,
        interestAmount,
        dueDate: new Date(),
      })
      .returning();
    return repayment;
  }

  async getRepaymentsByLoan(loanId: string): Promise<Repayment[]> {
    return db.select().from(repayments).where(eq(repayments.loanId, loanId)).orderBy(desc(repayments.submittedAt));
  }

  async getPendingPayments(): Promise<Repayment[]> {
    return db.select().from(repayments).where(eq(repayments.status, 'pending')).orderBy(desc(repayments.submittedAt));
  }

  async verifyPayment(id: string): Promise<Repayment | undefined> {
    const [repayment] = await db
      .update(repayments)
      .set({ status: 'verified', verifiedAt: new Date() })
      .where(eq(repayments.id, id))
      .returning();
    return repayment;
  }

  // Dividends
  async createDividend(userId: string, month: string, amount: number, ownershipPercent: number): Promise<Dividend> {
    const [dividend] = await db
      .insert(dividends)
      .values({ userId, month, amount, ownershipPercent })
      .returning();
    return dividend;
  }

  async getDividendsByUser(userId: string): Promise<Dividend[]> {
    return db.select().from(dividends).where(eq(dividends.userId, userId)).orderBy(desc(dividends.distributedAt));
  }

  async getDividendsByMonth(month: string): Promise<Dividend[]> {
    return db.select().from(dividends).where(eq(dividends.month, month));
  }

  // Transactions
  async createTransaction(type: string, userId: string, amount: number, description: string, referenceId?: string): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values({ type: type as any, userId, amount, description, referenceId })
      .returning();
    return transaction;
  }

  async getTransactionsByUser(userId: string): Promise<Transaction[]> {
    return db.select().from(transactions).where(eq(transactions.userId, userId)).orderBy(desc(transactions.createdAt));
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return db.select().from(transactions).orderBy(desc(transactions.createdAt));
  }

  // Settings
  async getSettings(): Promise<SystemSettings> {
    let [settings] = await db.select().from(systemSettings);
    if (!settings) {
      [settings] = await db.insert(systemSettings).values({}).returning();
    }
    return settings;
  }

  async updateSettings(data: Partial<InsertSettings>): Promise<SystemSettings> {
    const settings = await this.getSettings();
    const [updated] = await db
      .update(systemSettings)
      .set(data)
      .where(eq(systemSettings.id, settings.id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
