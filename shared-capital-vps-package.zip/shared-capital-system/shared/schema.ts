import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoleEnum = pgEnum('user_role', ['user', 'admin']);
export const loanStatusEnum = pgEnum('loan_status', ['pending', 'active', 'paid', 'rejected']);
export const repaymentStatusEnum = pgEnum('repayment_status', ['pending', 'verified']);
export const shareRequestStatusEnum = pgEnum('share_request_status', ['pending', 'approved', 'rejected']);
export const transactionTypeEnum = pgEnum('transaction_type', ['share_purchase', 'loan_disbursement', 'repayment', 'dividend']);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull().default('user'),
});

export const shareAccounts = pgTable("share_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  shares: integer("shares").notNull().default(0),
  totalInvested: real("total_invested").notNull().default(0),
});

export const shareRequests = pgTable("share_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  shares: integer("shares").notNull(),
  amount: real("amount").notNull(),
  status: shareRequestStatusEnum("status").notNull().default('pending'),
  requestedAt: timestamp("requested_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
});

export const capitalPool = pgTable("capital_pool", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  totalShares: integer("total_shares").notNull().default(0),
  totalBalance: real("total_balance").notNull().default(0),
});

export const loans = pgTable("loans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  principal: real("principal").notNull(),
  interestRate: real("interest_rate").notNull().default(0.02),
  termMonths: integer("term_months").notNull().default(5),
  remainingMonths: integer("remaining_months").notNull().default(5),
  totalPaid: real("total_paid").notNull().default(0),
  totalInterestAccrued: real("total_interest_accrued").notNull().default(0),
  lastInterestDate: timestamp("last_interest_date"),
  status: loanStatusEnum("status").notNull().default('pending'),
  requestedAt: timestamp("requested_at").notNull().defaultNow(),
  approvedAt: timestamp("approved_at"),
});

export const repayments = pgTable("repayments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  loanId: varchar("loan_id").notNull().references(() => loans.id),
  amount: real("amount").notNull(),
  principalAmount: real("principal_amount").notNull().default(0),
  interestAmount: real("interest_amount").notNull().default(0),
  dueDate: timestamp("due_date").notNull().defaultNow(),
  status: repaymentStatusEnum("status").notNull().default('pending'),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  verifiedAt: timestamp("verified_at"),
  paidAt: timestamp("paid_at"),
});

export const dividends = pgTable("dividends", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  month: text("month").notNull(),
  amount: real("amount").notNull(),
  ownershipPercent: real("ownership_percent").notNull(),
  distributedAt: timestamp("distributed_at").notNull().defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: transactionTypeEnum("type").notNull(),
  userId: varchar("user_id").notNull().references(() => users.id),
  amount: real("amount").notNull(),
  description: text("description").notNull(),
  referenceId: varchar("reference_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  systemName: text("system_name").notNull().default('Shared Capital Loan System'),
  logoUrl: text("logo_url"),
  interestRate: real("interest_rate").notNull().default(0.02),
  sharePrice: real("share_price").notNull().default(500),
  loanTermMonths: integer("loan_term_months").notNull().default(5),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  name: true,
  email: true,
  password: true,
});

export const registerUserSchema = insertUserSchema.extend({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(1, "Name is required"),
});

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const insertShareRequestSchema = createInsertSchema(shareRequests).pick({
  shares: true,
});

export const insertLoanSchema = createInsertSchema(loans).pick({
  principal: true,
});

export const insertRepaymentSchema = createInsertSchema(repayments).pick({
  amount: true,
});

export const insertSettingsSchema = createInsertSchema(systemSettings).pick({
  systemName: true,
  logoUrl: true,
  interestRate: true,
  sharePrice: true,
  loanTermMonths: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type ShareAccount = typeof shareAccounts.$inferSelect;
export type ShareRequest = typeof shareRequests.$inferSelect;
export type CapitalPool = typeof capitalPool.$inferSelect;
export type Loan = typeof loans.$inferSelect;
export type Repayment = typeof repayments.$inferSelect;
export type Dividend = typeof dividends.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type SystemSettings = typeof systemSettings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
